-- Sistema Hospitalario - Backup Database
-- Generado el: 2025-12-05 23:54:20
-- Host: localhost:3307
-- Database: hospital_db

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;

-- --------------------------------------------------------
-- Estructura de tabla para `alerta_medicamento`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `alerta_medicamento`;
CREATE TABLE `alerta_medicamento` (
  `id_alerta` int(11) NOT NULL AUTO_INCREMENT,
  `id_medicamento` int(11) NOT NULL,
  `tipo_alerta` enum('Stock bajo','Stock mínimo','Próximo a vencer','Vencido','Faltante') NOT NULL,
  `descripcion` text NOT NULL,
  `fecha_generacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `estado_alerta` enum('Pendiente','En revisión','Atendida','Ignorada') DEFAULT 'Pendiente',
  `fecha_atencion` timestamp NULL DEFAULT NULL,
  `atendido_por` int(11) DEFAULT NULL,
  `observaciones_atencion` text DEFAULT NULL,
  PRIMARY KEY (`id_alerta`),
  KEY `atendido_por` (`atendido_por`),
  KEY `idx_medicamento` (`id_medicamento`),
  KEY `idx_tipo` (`tipo_alerta`),
  KEY `idx_estado` (`estado_alerta`),
  KEY `idx_fecha` (`fecha_generacion`),
  CONSTRAINT `alerta_medicamento_ibfk_1` FOREIGN KEY (`id_medicamento`) REFERENCES `medicamento` (`id_medicamento`),
  CONSTRAINT `alerta_medicamento_ibfk_2` FOREIGN KEY (`atendido_por`) REFERENCES `personal` (`id_personal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Alertas de inventario';

-- --------------------------------------------------------
-- Estructura de tabla para `asignacion_turno`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `asignacion_turno`;
CREATE TABLE `asignacion_turno` (
  `id_asignacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_personal` int(11) NOT NULL,
  `id_turno` int(11) NOT NULL,
  `id_departamento` int(11) DEFAULT NULL,
  `fecha` date NOT NULL,
  `estado_asistencia` enum('Programado','Cumplido','Falta','Justificada','Tarde','Permiso') DEFAULT 'Programado',
  `hora_entrada` time DEFAULT NULL,
  `hora_salida` time DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `registrado_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_asignacion`),
  KEY `id_departamento` (`id_departamento`),
  KEY `registrado_por` (`registrado_por`),
  KEY `idx_personal` (`id_personal`),
  KEY `idx_fecha` (`fecha`),
  KEY `idx_turno` (`id_turno`),
  KEY `idx_estado` (`estado_asistencia`),
  CONSTRAINT `asignacion_turno_ibfk_1` FOREIGN KEY (`id_personal`) REFERENCES `personal` (`id_personal`),
  CONSTRAINT `asignacion_turno_ibfk_2` FOREIGN KEY (`id_turno`) REFERENCES `turno` (`id_turno`),
  CONSTRAINT `asignacion_turno_ibfk_3` FOREIGN KEY (`id_departamento`) REFERENCES `departamento` (`id_departamento`),
  CONSTRAINT `asignacion_turno_ibfk_4` FOREIGN KEY (`registrado_por`) REFERENCES `personal` (`id_personal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Asignación de turnos al personal';

-- --------------------------------------------------------
-- Estructura de tabla para `backup`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `backup`;
CREATE TABLE `backup` (
  `id_backup` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_backup` enum('Completo','Incremental','Diferencial','Transaccional') NOT NULL,
  `fecha_inicio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_fin` timestamp NULL DEFAULT NULL,
  `duracion_minutos` int(11) DEFAULT NULL,
  `tamanio_mb` decimal(10,2) DEFAULT NULL,
  `ubicacion_archivo` varchar(500) NOT NULL,
  `hash_verificacion` varchar(255) DEFAULT NULL,
  `estado_backup` enum('En proceso','Completado','Fallido','Corrupto','Restaurado') DEFAULT 'En proceso',
  `cifrado` tinyint(1) DEFAULT 1,
  `comprimido` tinyint(1) DEFAULT 1,
  `observaciones` text DEFAULT NULL,
  `realizado_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_backup`),
  KEY `realizado_por` (`realizado_por`),
  KEY `idx_fecha_inicio` (`fecha_inicio`),
  KEY `idx_tipo` (`tipo_backup`),
  KEY `idx_estado` (`estado_backup`),
  CONSTRAINT `backup_ibfk_1` FOREIGN KEY (`realizado_por`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro de backups';

-- Volcado de datos para la tabla `backup`

INSERT INTO `backup` VALUES ('3', 'Completo', '2025-12-05 23:54:19', NULL, NULL, NULL, '', NULL, 'En proceso', '1', '1', 'Primer backup', '1');

-- --------------------------------------------------------
-- Estructura de tabla para `cama`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cama`;
CREATE TABLE `cama` (
  `id_cama` int(11) NOT NULL AUTO_INCREMENT,
  `id_habitacion` int(11) NOT NULL,
  `numero_cama` varchar(10) NOT NULL,
  `tipo_cama` enum('Estándar','Eléctrica','UCI','Pediátrica') DEFAULT 'Estándar',
  `estado_cama` enum('Disponible','Ocupada','Mantenimiento','Limpieza') DEFAULT 'Disponible',
  `observaciones` text DEFAULT NULL,
  PRIMARY KEY (`id_cama`),
  UNIQUE KEY `unique_cama` (`id_habitacion`,`numero_cama`),
  KEY `idx_habitacion` (`id_habitacion`),
  KEY `idx_estado` (`estado_cama`),
  CONSTRAINT `cama_ibfk_1` FOREIGN KEY (`id_habitacion`) REFERENCES `habitacion` (`id_habitacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Camas hospitalarias';

-- --------------------------------------------------------
-- Estructura de tabla para `categoria_medicamento`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `categoria_medicamento`;
CREATE TABLE `categoria_medicamento` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `requiere_control_especial` tinyint(1) DEFAULT 0,
  `estado` enum('activa','inactiva') DEFAULT 'activa',
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `idx_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Categorías de medicamentos';

-- Volcado de datos para la tabla `categoria_medicamento`

INSERT INTO `categoria_medicamento` VALUES ('1', 'Analgésicos', 'Medicamentos para el dolor', '0', 'activa');
INSERT INTO `categoria_medicamento` VALUES ('2', 'Antibióticos', 'Tratamiento de infecciones bacterianas', '0', 'activa');
INSERT INTO `categoria_medicamento` VALUES ('3', 'Antiinflamatorios', 'Reducen la inflamación', '0', 'activa');
INSERT INTO `categoria_medicamento` VALUES ('4', 'Antipiréticos', 'Reducen la fiebre', '0', 'activa');
INSERT INTO `categoria_medicamento` VALUES ('5', 'Antihipertensivos', 'Control de presión arterial', '0', 'activa');
INSERT INTO `categoria_medicamento` VALUES ('6', 'Psicotrópicos', 'Salud mental', '1', 'activa');
INSERT INTO `categoria_medicamento` VALUES ('7', 'Narcóticos', 'Control del dolor severo', '1', 'activa');
INSERT INTO `categoria_medicamento` VALUES ('8', 'Antidiabéticos', 'Control de diabetes', '0', 'activa');

-- --------------------------------------------------------
-- Estructura de tabla para `cita`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cita`;
CREATE TABLE `cita` (
  `id_cita` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) NOT NULL,
  `id_medico` int(11) NOT NULL,
  `fecha_cita` date NOT NULL,
  `hora_cita` time NOT NULL,
  `motivo_consulta` varchar(500) DEFAULT NULL,
  `tipo_cita` enum('Primera vez','Control','Emergencia','Especializada') DEFAULT 'Primera vez',
  `estado_cita` enum('Programada','Confirmada','En espera','Atendida','Cancelada','No asistió') DEFAULT 'Programada',
  `observaciones` text DEFAULT NULL,
  `consultorio` varchar(50) DEFAULT NULL,
  `recordatorio_enviado` tinyint(1) DEFAULT 0,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `registrado_por` int(11) DEFAULT NULL,
  `fecha_cancelacion` timestamp NULL DEFAULT NULL,
  `motivo_cancelacion` varchar(500) DEFAULT NULL,
  `costo_cita` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_cita`),
  KEY `registrado_por` (`registrado_por`),
  KEY `idx_paciente` (`id_paciente`),
  KEY `idx_medico` (`id_medico`),
  KEY `idx_fecha_cita` (`fecha_cita`),
  KEY `idx_estado` (`estado_cita`),
  KEY `idx_fecha_hora` (`fecha_cita`,`hora_cita`),
  CONSTRAINT `cita_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`),
  CONSTRAINT `cita_ibfk_2` FOREIGN KEY (`id_medico`) REFERENCES `medico` (`id_medico`),
  CONSTRAINT `cita_ibfk_3` FOREIGN KEY (`registrado_por`) REFERENCES `personal` (`id_personal`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Citas médicas programadas';

-- Volcado de datos para la tabla `cita`

INSERT INTO `cita` VALUES ('1', '5', '20', '2025-12-08', '14:00:00', 'Dolores en el estomago agudos, tomo arocarbol y sigue el dolor.', 'Primera vez', 'Confirmada', '', 'Consultorio 103', '0', '2025-12-05 12:25:35', '1', NULL, NULL, '300.00');
INSERT INTO `cita` VALUES ('2', '5', '11', '2025-12-05', '13:00:00', 'Golpe en la cabeza, con dolor', 'Control', 'Atendida', '', 'Consultorio 107', '0', '2025-12-05 12:29:09', '1', NULL, NULL, '150.00');

-- --------------------------------------------------------
-- Estructura de tabla para `configuracion_sistema`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `configuracion_sistema`;
CREATE TABLE `configuracion_sistema` (
  `id_config` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(100) NOT NULL,
  `parametro` varchar(100) NOT NULL,
  `valor` text NOT NULL,
  `tipo_dato` enum('String','Integer','Boolean','JSON','Decimal') DEFAULT 'String',
  `descripcion` text DEFAULT NULL,
  `modificable` tinyint(1) DEFAULT 1,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `modificado_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_config`),
  UNIQUE KEY `unique_parametro` (`categoria`,`parametro`),
  KEY `modificado_por` (`modificado_por`),
  KEY `idx_categoria` (`categoria`),
  CONSTRAINT `configuracion_sistema_ibfk_1` FOREIGN KEY (`modificado_por`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Configuración del sistema';

-- --------------------------------------------------------
-- Estructura de tabla para `consulta`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `consulta`;
CREATE TABLE `consulta` (
  `id_consulta` int(11) NOT NULL AUTO_INCREMENT,
  `id_cita` int(11) DEFAULT NULL,
  `id_paciente` int(11) NOT NULL,
  `id_medico` int(11) NOT NULL,
  `fecha_hora_atencion` timestamp NOT NULL DEFAULT current_timestamp(),
  `motivo_consulta` text DEFAULT NULL COMMENT 'Encriptado',
  `sintomas` text DEFAULT NULL COMMENT 'Encriptado',
  `diagnostico` text DEFAULT NULL COMMENT 'Encriptado',
  `tratamiento` text DEFAULT NULL COMMENT 'Encriptado',
  `observaciones` text DEFAULT NULL COMMENT 'Encriptado',
  `plan_seguimiento` text DEFAULT NULL COMMENT 'Encriptado',
  `proxima_cita` date DEFAULT NULL,
  `presion_arterial` varchar(20) DEFAULT NULL,
  `temperatura` decimal(4,2) DEFAULT NULL,
  `peso` decimal(5,2) DEFAULT NULL,
  `altura` decimal(5,2) DEFAULT NULL,
  `frecuencia_cardiaca` int(11) DEFAULT NULL,
  `frecuencia_respiratoria` int(11) DEFAULT NULL,
  `saturacion_oxigeno` int(11) DEFAULT NULL,
  `tipo_consulta` enum('Ambulatoria','Emergencia','Control','Domiciliaria') DEFAULT 'Ambulatoria',
  `estado_consulta` enum('En proceso','Finalizada','Cancelada') DEFAULT 'En proceso',
  `duracion_minutos` int(11) DEFAULT NULL,
  `costo_consulta` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_consulta`),
  KEY `id_cita` (`id_cita`),
  KEY `idx_paciente` (`id_paciente`),
  KEY `idx_medico` (`id_medico`),
  KEY `idx_fecha` (`fecha_hora_atencion`),
  KEY `idx_tipo` (`tipo_consulta`),
  KEY `idx_estado` (`estado_consulta`),
  CONSTRAINT `consulta_ibfk_1` FOREIGN KEY (`id_cita`) REFERENCES `cita` (`id_cita`),
  CONSTRAINT `consulta_ibfk_2` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`),
  CONSTRAINT `consulta_ibfk_3` FOREIGN KEY (`id_medico`) REFERENCES `medico` (`id_medico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Consultas médicas realizadas';

-- --------------------------------------------------------
-- Estructura de tabla para `dato_enmascarado`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `dato_enmascarado`;
CREATE TABLE `dato_enmascarado` (
  `id_dato` int(11) NOT NULL AUTO_INCREMENT,
  `tabla_origen` varchar(100) NOT NULL,
  `columna_origen` varchar(100) NOT NULL,
  `registro_id` int(11) NOT NULL,
  `valor_enmascarado` varbinary(255) NOT NULL,
  `tecnica_enmascaramiento` enum('Parcial','Aleatorio','Hash','Nulo','Sustitución','Redacción') NOT NULL,
  `puede_revertir` tinyint(1) DEFAULT 0,
  `patron_mascara` varchar(50) DEFAULT NULL,
  `fecha_enmascaramiento` timestamp NOT NULL DEFAULT current_timestamp(),
  `enmascarado_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_dato`),
  UNIQUE KEY `unique_dato` (`tabla_origen`,`columna_origen`,`registro_id`),
  KEY `enmascarado_por` (`enmascarado_por`),
  KEY `idx_tabla` (`tabla_origen`),
  KEY `idx_fecha` (`fecha_enmascaramiento`),
  CONSTRAINT `dato_enmascarado_ibfk_1` FOREIGN KEY (`enmascarado_por`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Datos enmascarados para ambientes no productivos';

-- --------------------------------------------------------
-- Estructura de tabla para `departamento`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `departamento`;
CREATE TABLE `departamento` (
  `id_departamento` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `jefe_departamento` int(11) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `estado` enum('activo','inactivo') DEFAULT 'activo',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_departamento`),
  KEY `idx_nombre` (`nombre`),
  KEY `idx_estado` (`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Departamentos del hospital';

-- Volcado de datos para la tabla `departamento`

INSERT INTO `departamento` VALUES ('1', 'Emergencias', 'Atención de urgencias 24/7', 'Planta Baja', NULL, NULL, 'activo', '2025-11-30 03:22:28');
INSERT INTO `departamento` VALUES ('2', 'Consulta Externa', 'Consultas médicas programadas', 'Primer Piso', NULL, NULL, 'activo', '2025-11-30 03:22:28');
INSERT INTO `departamento` VALUES ('3', 'Hospitalización', 'Internamiento de pacientes', 'Segundo Piso', NULL, NULL, 'activo', '2025-11-30 03:22:28');
INSERT INTO `departamento` VALUES ('4', 'Farmacia', 'Dispensación de medicamentos', 'Planta Baja', NULL, NULL, 'activo', '2025-11-30 03:22:28');
INSERT INTO `departamento` VALUES ('5', 'Laboratorio', 'Análisis clínicos', 'Planta Baja', NULL, NULL, 'activo', '2025-11-30 03:22:28');
INSERT INTO `departamento` VALUES ('6', 'Imagenología', 'Rayos X, Tomografía, Ecografía', 'Primer Piso', NULL, NULL, 'activo', '2025-11-30 03:22:28');
INSERT INTO `departamento` VALUES ('7', 'Quirófano', 'Cirugías', 'Tercer Piso', NULL, NULL, 'activo', '2025-11-30 03:22:28');
INSERT INTO `departamento` VALUES ('8', 'Administración', 'Gestión administrativa', 'Planta Baja', NULL, NULL, 'activo', '2025-11-30 03:22:28');

-- --------------------------------------------------------
-- Estructura de tabla para `detalle_receta`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `detalle_receta`;
CREATE TABLE `detalle_receta` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `id_receta` int(11) NOT NULL,
  `id_medicamento` int(11) NOT NULL,
  `dosis` varchar(100) NOT NULL,
  `frecuencia` varchar(100) NOT NULL COMMENT 'Cada 8 horas, 3 veces al día, etc.',
  `duracion_dias` int(11) NOT NULL,
  `cantidad_total` int(11) NOT NULL,
  `cantidad_surtida` int(11) DEFAULT 0,
  `indicaciones_especiales` text DEFAULT NULL COMMENT 'Encriptado',
  `via_administracion` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_detalle`),
  KEY `idx_receta` (`id_receta`),
  KEY `idx_medicamento` (`id_medicamento`),
  CONSTRAINT `detalle_receta_ibfk_1` FOREIGN KEY (`id_receta`) REFERENCES `receta_medica` (`id_receta`) ON DELETE CASCADE,
  CONSTRAINT `detalle_receta_ibfk_2` FOREIGN KEY (`id_medicamento`) REFERENCES `medicamento` (`id_medicamento`),
  CONSTRAINT `chk_cantidad_valida` CHECK (`cantidad_total` > 0),
  CONSTRAINT `chk_duracion_valida` CHECK (`duracion_dias` > 0),
  CONSTRAINT `chk_surtido_valido` CHECK (`cantidad_surtida` <= `cantidad_total`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Detalle de medicamentos en recetas';

-- --------------------------------------------------------
-- Estructura de tabla para `documento_medico`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `documento_medico`;
CREATE TABLE `documento_medico` (
  `id_documento` int(11) NOT NULL AUTO_INCREMENT,
  `id_consulta` int(11) NOT NULL,
  `tipo_documento` enum('Receta','Orden Examen','Certificado','Informe','Referencia','Constancia') NOT NULL,
  `contenido` text DEFAULT NULL COMMENT 'Encriptado',
  `fecha_emision` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_validez` date DEFAULT NULL,
  `id_medico_emisor` int(11) NOT NULL,
  `numero_documento` varchar(50) DEFAULT NULL,
  `ruta_archivo` varchar(500) DEFAULT NULL,
  `firmado_digitalmente` tinyint(1) DEFAULT 0,
  `hash_documento` varchar(255) DEFAULT NULL,
  `estado` enum('Vigente','Vencido','Anulado') DEFAULT 'Vigente',
  PRIMARY KEY (`id_documento`),
  UNIQUE KEY `numero_documento` (`numero_documento`),
  KEY `id_medico_emisor` (`id_medico_emisor`),
  KEY `idx_consulta` (`id_consulta`),
  KEY `idx_tipo` (`tipo_documento`),
  KEY `idx_fecha_emision` (`fecha_emision`),
  KEY `idx_estado` (`estado`),
  CONSTRAINT `documento_medico_ibfk_1` FOREIGN KEY (`id_consulta`) REFERENCES `consulta` (`id_consulta`),
  CONSTRAINT `documento_medico_ibfk_2` FOREIGN KEY (`id_medico_emisor`) REFERENCES `medico` (`id_medico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Documentos médicos generados';

-- --------------------------------------------------------
-- Estructura de tabla para `especialidad`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `especialidad`;
CREATE TABLE `especialidad` (
  `id_especialidad` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `estado` enum('activa','inactiva') DEFAULT 'activa',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_especialidad`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `idx_nombre` (`nombre`),
  KEY `idx_estado` (`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Especialidades médicas';

-- Volcado de datos para la tabla `especialidad`

INSERT INTO `especialidad` VALUES ('1', 'Medicina General', 'Atención médica general', 'activa', '2025-11-30 03:22:28');
INSERT INTO `especialidad` VALUES ('2', 'Pediatría', 'Atención de niños y adolescentes', 'activa', '2025-11-30 03:22:28');
INSERT INTO `especialidad` VALUES ('3', 'Ginecología y Obstetricia', 'Salud de la mujer y embarazo', 'activa', '2025-11-30 03:22:28');
INSERT INTO `especialidad` VALUES ('4', 'Cardiología', 'Enfermedades del corazón', 'activa', '2025-11-30 03:22:28');
INSERT INTO `especialidad` VALUES ('5', 'Traumatología', 'Lesiones y enfermedades del sistema músculo-esquelético', 'activa', '2025-11-30 03:22:28');
INSERT INTO `especialidad` VALUES ('6', 'Neurología', 'Enfermedades del sistema nervioso', 'activa', '2025-11-30 03:22:28');
INSERT INTO `especialidad` VALUES ('7', 'Dermatología', 'Enfermedades de la piel', 'activa', '2025-11-30 03:22:28');
INSERT INTO `especialidad` VALUES ('8', 'Oftalmología', 'Enfermedades de los ojos', 'activa', '2025-11-30 03:22:28');
INSERT INTO `especialidad` VALUES ('9', 'Otorrinolaringología', 'Oído, nariz y garganta', 'activa', '2025-11-30 03:22:28');
INSERT INTO `especialidad` VALUES ('10', 'Urología', 'Sistema urinario', 'activa', '2025-11-30 03:22:28');

-- --------------------------------------------------------
-- Estructura de tabla para `evolucion_medica`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `evolucion_medica`;
CREATE TABLE `evolucion_medica` (
  `id_evolucion` int(11) NOT NULL AUTO_INCREMENT,
  `id_internamiento` int(11) NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_medico` int(11) NOT NULL,
  `nota_evolucion` text DEFAULT NULL COMMENT 'Encriptado',
  `signos_vitales` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'PA, FC, Temp, etc - Encriptado' CHECK (json_valid(`signos_vitales`)),
  `plan_tratamiento` text DEFAULT NULL COMMENT 'Encriptado',
  `estudios_solicitados` text DEFAULT NULL,
  `condicion_general` enum('Estable','Delicado','Crítico','Mejoría','Sin cambios','Deterioro') DEFAULT NULL,
  PRIMARY KEY (`id_evolucion`),
  KEY `idx_internamiento` (`id_internamiento`),
  KEY `idx_fecha` (`fecha_hora`),
  KEY `idx_medico` (`id_medico`),
  CONSTRAINT `evolucion_medica_ibfk_1` FOREIGN KEY (`id_internamiento`) REFERENCES `internamiento` (`id_internamiento`) ON DELETE CASCADE,
  CONSTRAINT `evolucion_medica_ibfk_2` FOREIGN KEY (`id_medico`) REFERENCES `medico` (`id_medico`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Evoluciones médicas durante internamiento';

-- Volcado de datos para la tabla `evolucion_medica`

INSERT INTO `evolucion_medica` VALUES ('1', '1', '2025-12-05 13:01:58', '11', 'Ya no nesesita respirador empieza haber cambios', '{\"presion_arterial\":\"160\",\"frecuencia_cardiaca\":\"71\",\"temperatura\":\"35\",\"frecuencia_respiratoria\":\"15\",\"saturacion_oxigeno\":\"97\"}', 'Medicacion ', NULL, 'Delicado');

-- --------------------------------------------------------
-- Estructura de tabla para `habitacion`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `habitacion`;
CREATE TABLE `habitacion` (
  `id_habitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_sala` int(11) NOT NULL,
  `numero_habitacion` varchar(20) NOT NULL,
  `tipo_habitacion` enum('Individual','Compartida','Suite','UCI') NOT NULL,
  `numero_camas` int(11) NOT NULL,
  `camas_ocupadas` int(11) DEFAULT 0,
  `precio_dia` decimal(10,2) NOT NULL,
  `tiene_bano_privado` tinyint(1) DEFAULT 0,
  `tiene_television` tinyint(1) DEFAULT 0,
  `tiene_aire_acondicionado` tinyint(1) DEFAULT 0,
  `estado_habitacion` enum('Disponible','Ocupada','Mantenimiento','Limpieza','Reservada') DEFAULT 'Disponible',
  PRIMARY KEY (`id_habitacion`),
  UNIQUE KEY `unique_habitacion` (`id_sala`,`numero_habitacion`),
  KEY `idx_sala` (`id_sala`),
  KEY `idx_tipo` (`tipo_habitacion`),
  KEY `idx_estado` (`estado_habitacion`),
  CONSTRAINT `habitacion_ibfk_1` FOREIGN KEY (`id_sala`) REFERENCES `sala` (`id_sala`),
  CONSTRAINT `chk_camas_habitacion` CHECK (`camas_ocupadas` >= 0 and `camas_ocupadas` <= `numero_camas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Habitaciones del hospital';

-- --------------------------------------------------------
-- Estructura de tabla para `historial_clinico`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `historial_clinico`;
CREATE TABLE `historial_clinico` (
  `id_historial` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) NOT NULL,
  `antecedentes_personales` text DEFAULT NULL COMMENT 'Encriptado',
  `antecedentes_familiares` text DEFAULT NULL COMMENT 'Encriptado',
  `cirugias_previas` text DEFAULT NULL COMMENT 'Encriptado',
  `hospitalizaciones_previas` text DEFAULT NULL COMMENT 'Encriptado',
  `medicamentos_actuales` text DEFAULT NULL COMMENT 'Encriptado',
  `habitos` text DEFAULT NULL COMMENT 'Encriptado',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultima_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `actualizado_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_historial`),
  UNIQUE KEY `id_paciente` (`id_paciente`),
  KEY `actualizado_por` (`actualizado_por`),
  CONSTRAINT `historial_clinico_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`) ON DELETE CASCADE,
  CONSTRAINT `historial_clinico_ibfk_2` FOREIGN KEY (`actualizado_por`) REFERENCES `medico` (`id_medico`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Historial clínico de pacientes';

-- Volcado de datos para la tabla `historial_clinico`

INSERT INTO `historial_clinico` VALUES ('1', '2', NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-30 03:47:43', '2025-11-30 03:47:43', NULL);
INSERT INTO `historial_clinico` VALUES ('2', '3', NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-30 21:26:36', '2025-11-30 21:26:36', NULL);
INSERT INTO `historial_clinico` VALUES ('3', '4', NULL, NULL, NULL, NULL, NULL, NULL, '2025-12-04 15:13:47', '2025-12-04 15:13:47', NULL);
INSERT INTO `historial_clinico` VALUES ('4', '5', NULL, NULL, NULL, NULL, NULL, NULL, '2025-12-04 16:20:30', '2025-12-04 16:20:30', NULL);

-- --------------------------------------------------------
-- Estructura de tabla para `historial_rotacion_llaves`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `historial_rotacion_llaves`;
CREATE TABLE `historial_rotacion_llaves` (
  `id_rotacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_llave_anterior` int(11) NOT NULL,
  `id_llave_nueva` int(11) NOT NULL,
  `fecha_rotacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `motivo` text DEFAULT NULL,
  `registros_re_encriptados` int(11) DEFAULT 0,
  `estado_proceso` enum('En proceso','Completado','Fallido') DEFAULT 'En proceso',
  `realizado_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_rotacion`),
  KEY `id_llave_anterior` (`id_llave_anterior`),
  KEY `id_llave_nueva` (`id_llave_nueva`),
  KEY `realizado_por` (`realizado_por`),
  KEY `idx_fecha` (`fecha_rotacion`),
  CONSTRAINT `historial_rotacion_llaves_ibfk_1` FOREIGN KEY (`id_llave_anterior`) REFERENCES `llave_cifrado` (`id_llave`),
  CONSTRAINT `historial_rotacion_llaves_ibfk_2` FOREIGN KEY (`id_llave_nueva`) REFERENCES `llave_cifrado` (`id_llave`),
  CONSTRAINT `historial_rotacion_llaves_ibfk_3` FOREIGN KEY (`realizado_por`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Historial de rotación de llaves';

-- --------------------------------------------------------
-- Estructura de tabla para `horario_medico`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `horario_medico`;
CREATE TABLE `horario_medico` (
  `id_horario` int(11) NOT NULL AUTO_INCREMENT,
  `id_medico` int(11) NOT NULL,
  `dia_semana` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo') NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `consultorio` varchar(50) DEFAULT NULL,
  `cupo_maximo` int(11) DEFAULT 20,
  `duracion_cita` int(11) DEFAULT 30 COMMENT 'Minutos por cita',
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id_horario`),
  KEY `idx_medico_dia` (`id_medico`,`dia_semana`),
  KEY `idx_activo` (`activo`),
  CONSTRAINT `horario_medico_ibfk_1` FOREIGN KEY (`id_medico`) REFERENCES `medico` (`id_medico`) ON DELETE CASCADE,
  CONSTRAINT `chk_horario_valido` CHECK (`hora_inicio` < `hora_fin`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Horarios de atención de médicos';

-- Volcado de datos para la tabla `horario_medico`

INSERT INTO `horario_medico` VALUES ('2', '20', 'Lunes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('3', '20', 'Martes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('4', '20', 'Miércoles', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('5', '20', 'Jueves', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('6', '20', 'Viernes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('7', '20', 'Sábado', '08:00:00', '12:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('8', '16', 'Lunes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('9', '16', 'Martes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('10', '16', 'Miércoles', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('11', '16', 'Jueves', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('12', '16', 'Viernes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('13', '16', 'Sábado', '08:00:00', '12:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('14', '14', 'Lunes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('15', '14', 'Martes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('16', '14', 'Miércoles', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('17', '14', 'Jueves', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('18', '14', 'Viernes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('19', '14', 'Sábado', '08:00:00', '12:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('20', '8', 'Lunes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('21', '8', 'Martes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('22', '8', 'Miércoles', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('23', '8', 'Jueves', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('24', '8', 'Viernes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('25', '8', 'Sábado', '08:00:00', '12:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('27', '6', 'Lunes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('28', '6', 'Martes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('29', '6', 'Miércoles', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('30', '6', 'Jueves', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('31', '6', 'Viernes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('33', '6', 'Sábado', '08:00:00', '12:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('34', '11', 'Lunes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('35', '11', 'Martes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('36', '11', 'Miércoles', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('37', '11', 'Jueves', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('38', '11', 'Viernes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('39', '11', 'Sábado', '08:00:00', '12:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('40', '10', 'Lunes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('41', '10', 'Martes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('42', '10', 'Miércoles', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('43', '10', 'Jueves', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('44', '10', 'Viernes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('45', '10', 'Sábado', '08:00:00', '12:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('46', '7', 'Lunes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('47', '7', 'Martes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('48', '7', 'Miércoles', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('49', '7', 'Jueves', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('50', '7', 'Viernes', '08:00:00', '18:00:00', NULL, '20', '30', '1');
INSERT INTO `horario_medico` VALUES ('51', '7', 'Sábado', '08:00:00', '12:00:00', NULL, '20', '30', '1');

-- --------------------------------------------------------
-- Estructura de tabla para `internamiento`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `internamiento`;
CREATE TABLE `internamiento` (
  `id_internamiento` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) NOT NULL,
  `id_cama` int(11) DEFAULT NULL,
  `id_medico_responsable` int(11) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `hora_ingreso` time NOT NULL,
  `motivo_internamiento` text DEFAULT NULL COMMENT 'Encriptado',
  `diagnostico_ingreso` text DEFAULT NULL COMMENT 'Encriptado',
  `tipo_internamiento` enum('Programado','Emergencia','Referencia') DEFAULT 'Programado',
  `estado_internamiento` enum('En curso','Alta médica','Alta voluntaria','Referido','Fallecido') DEFAULT 'En curso',
  `fecha_alta` date DEFAULT NULL,
  `hora_alta` time DEFAULT NULL,
  `diagnostico_alta` text DEFAULT NULL COMMENT 'Encriptado',
  `recomendaciones_alta` text DEFAULT NULL COMMENT 'Encriptado',
  `pronostico` varchar(100) DEFAULT NULL,
  `dias_hospitalizacion` int(11) DEFAULT NULL,
  `costo_dia` decimal(10,2) DEFAULT NULL,
  `costo_total` decimal(10,2) DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  PRIMARY KEY (`id_internamiento`),
  KEY `id_cama` (`id_cama`),
  KEY `idx_paciente` (`id_paciente`),
  KEY `idx_medico` (`id_medico_responsable`),
  KEY `idx_fecha_ingreso` (`fecha_ingreso`),
  KEY `idx_estado` (`estado_internamiento`),
  CONSTRAINT `internamiento_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`),
  CONSTRAINT `internamiento_ibfk_2` FOREIGN KEY (`id_cama`) REFERENCES `cama` (`id_cama`),
  CONSTRAINT `internamiento_ibfk_3` FOREIGN KEY (`id_medico_responsable`) REFERENCES `medico` (`id_medico`),
  CONSTRAINT `chk_fechas_internamiento` CHECK (`fecha_alta` is null or `fecha_alta` >= `fecha_ingreso`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Internamientos hospitalarios';

-- Volcado de datos para la tabla `internamiento`

INSERT INTO `internamiento` VALUES ('1', '3', NULL, '11', '2025-12-05', '12:59:00', 'Golpe en la cabeza', 'Mal estado', 'Programado', 'En curso', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------
-- Estructura de tabla para `llave_cifrado`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `llave_cifrado`;
CREATE TABLE `llave_cifrado` (
  `id_llave` int(11) NOT NULL AUTO_INCREMENT,
  `identificador` varchar(100) NOT NULL,
  `algoritmo` enum('AES-256','RSA-2048','RSA-4096','ChaCha20') NOT NULL,
  `llave_publica` text DEFAULT NULL,
  `llave_privada_encriptada` blob NOT NULL,
  `vector_inicializacion` varbinary(255) DEFAULT NULL,
  `proposito` varchar(200) NOT NULL COMMENT 'Datos personales, Documentos médicos, etc.',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_expiracion` timestamp NULL DEFAULT NULL,
  `fecha_rotacion` timestamp NULL DEFAULT NULL,
  `activa` tinyint(1) DEFAULT 1,
  `version` int(11) DEFAULT 1,
  `creado_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_llave`),
  UNIQUE KEY `identificador` (`identificador`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_identificador` (`identificador`),
  KEY `idx_activa` (`activa`),
  KEY `idx_proposito` (`proposito`),
  CONSTRAINT `llave_cifrado_ibfk_1` FOREIGN KEY (`creado_por`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Gestión de llaves de cifrado';

-- --------------------------------------------------------
-- Estructura de tabla para `log_acceso_datos_sensibles`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `log_acceso_datos_sensibles`;
CREATE TABLE `log_acceso_datos_sensibles` (
  `id_log_sensible` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `tabla_accedida` varchar(100) NOT NULL,
  `registro_id` int(11) NOT NULL,
  `campo_accedido` varchar(100) DEFAULT NULL,
  `tipo_acceso` enum('Lectura','Escritura','Exportación','Impresión') NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `justificacion` text DEFAULT NULL,
  `aprobado_por` int(11) DEFAULT NULL COMMENT 'Supervisor que autorizó',
  PRIMARY KEY (`id_log_sensible`),
  KEY `aprobado_por` (`aprobado_por`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_fecha` (`fecha_hora`),
  KEY `idx_tabla` (`tabla_accedida`),
  KEY `idx_tipo` (`tipo_acceso`),
  CONSTRAINT `log_acceso_datos_sensibles_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `log_acceso_datos_sensibles_ibfk_2` FOREIGN KEY (`aprobado_por`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Auditoría específica de datos sensibles';

-- --------------------------------------------------------
-- Estructura de tabla para `log_auditoria`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `log_auditoria`;
CREATE TABLE `log_auditoria` (
  `id_log` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `id_sesion` int(11) DEFAULT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  `accion` enum('INSERT','UPDATE','DELETE','SELECT','LOGIN','LOGOUT','LOGIN_FAILED','EXECUTE','EXPORT') NOT NULL,
  `tabla_afectada` varchar(100) DEFAULT NULL,
  `registro_id` int(11) DEFAULT NULL,
  `valores_anteriores` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Encriptado' CHECK (json_valid(`valores_anteriores`)),
  `valores_nuevos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Encriptado' CHECK (json_valid(`valores_nuevos`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `navegador` varchar(200) DEFAULT NULL,
  `resultado` enum('Éxito','Fallo','Bloqueado','Error') DEFAULT 'Éxito',
  `codigo_error` varchar(50) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `criticidad` enum('Baja','Media','Alta','Crítica') DEFAULT 'Media',
  PRIMARY KEY (`id_log`),
  KEY `id_sesion` (`id_sesion`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_fecha` (`fecha_hora`),
  KEY `idx_accion` (`accion`),
  KEY `idx_tabla` (`tabla_afectada`),
  KEY `idx_resultado` (`resultado`),
  KEY `idx_criticidad` (`criticidad`),
  CONSTRAINT `log_auditoria_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL,
  CONSTRAINT `log_auditoria_ibfk_2` FOREIGN KEY (`id_sesion`) REFERENCES `sesion` (`id_sesion`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=400 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Log de auditoría completo';

-- Volcado de datos para la tabla `log_auditoria`

INSERT INTO `log_auditoria` VALUES ('1', '1', NULL, '2025-11-30 03:46:50', 'LOGIN', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('5', '1', NULL, '2025-11-30 03:51:46', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('6', '1', NULL, '2025-11-30 03:52:09', 'LOGIN', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('7', '1', NULL, '2025-11-30 12:11:29', 'LOGIN', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('10', '1', NULL, '2025-11-30 12:30:14', 'LOGIN', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('24', '1', NULL, '2025-11-30 12:33:19', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('25', '1', NULL, '2025-11-30 12:50:26', 'LOGIN', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('26', '1', NULL, '2025-11-30 21:25:08', 'LOGIN', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('38', '1', NULL, '2025-11-30 21:29:56', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('39', '1', NULL, '2025-11-30 21:30:01', 'LOGIN', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('52', '1', NULL, '2025-11-30 22:34:06', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('53', '1', NULL, '2025-11-30 22:40:10', 'LOGIN', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('54', '1', NULL, '2025-11-30 23:47:33', 'LOGIN', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('55', '1', NULL, '2025-11-30 23:59:47', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, NULL, 'Media');
INSERT INTO `log_auditoria` VALUES ('56', '1', NULL, '2025-12-01 00:00:01', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('57', '1', NULL, '2025-12-01 01:28:49', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('58', '1', NULL, '2025-12-01 04:40:14', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('59', '1', NULL, '2025-12-01 04:42:08', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Cierre de sesión', 'Media');
INSERT INTO `log_auditoria` VALUES ('60', '1', NULL, '2025-12-01 11:43:59', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('61', '1', NULL, '2025-12-01 13:42:39', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('62', '1', NULL, '2025-12-01 13:47:22', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('63', '1', NULL, '2025-12-01 13:52:18', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('64', '1', NULL, '2025-12-01 14:10:29', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('65', '1', NULL, '2025-12-01 14:38:22', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Cierre de sesión', 'Media');
INSERT INTO `log_auditoria` VALUES ('66', '1', NULL, '2025-12-01 14:51:41', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('67', '1', NULL, '2025-12-01 15:48:25', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Cierre de sesión', 'Media');
INSERT INTO `log_auditoria` VALUES ('68', '1', NULL, '2025-12-01 15:48:31', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('69', '1', NULL, '2025-12-01 15:48:38', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('70', '1', NULL, '2025-12-01 15:58:27', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Cierre de sesión', 'Media');
INSERT INTO `log_auditoria` VALUES ('71', '1', NULL, '2025-12-01 15:58:33', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('72', '1', NULL, '2025-12-01 16:14:41', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('73', '1', NULL, '2025-12-01 16:14:59', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: Alexander', 'Media');
INSERT INTO `log_auditoria` VALUES ('74', '1', NULL, '2025-12-01 16:15:05', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: Juan', 'Media');
INSERT INTO `log_auditoria` VALUES ('75', '1', NULL, '2025-12-01 16:15:09', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('76', '1', NULL, '2025-12-01 16:15:12', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: HC-2025-0002', 'Media');
INSERT INTO `log_auditoria` VALUES ('77', '1', NULL, '2025-12-01 16:15:48', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: Alexander', 'Media');
INSERT INTO `log_auditoria` VALUES ('78', '1', NULL, '2025-12-01 16:15:49', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('79', '1', NULL, '2025-12-01 16:16:20', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('80', '1', NULL, '2025-12-01 16:17:34', 'EXECUTE', 'MANUAL_QUERY', NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'SELECT * FROM PERSONA;', 'Media');
INSERT INTO `log_auditoria` VALUES ('81', '1', NULL, '2025-12-01 17:12:29', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Cierre de sesión', 'Media');
INSERT INTO `log_auditoria` VALUES ('82', '1', NULL, '2025-12-03 10:21:33', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('83', '1', NULL, '2025-12-03 11:36:58', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('84', '1', NULL, '2025-12-03 11:55:04', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('85', '1', NULL, '2025-12-03 11:58:16', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('86', '1', NULL, '2025-12-03 12:08:41', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('87', '1', NULL, '2025-12-03 12:13:24', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('88', '1', NULL, '2025-12-03 12:16:56', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('89', '1', NULL, '2025-12-03 16:28:50', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('90', '1', NULL, '2025-12-03 16:33:04', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-03', 'Media');
INSERT INTO `log_auditoria` VALUES ('91', '1', NULL, '2025-12-03 16:51:10', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('92', '1', NULL, '2025-12-03 16:53:08', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('93', '1', NULL, '2025-12-03 16:55:38', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('94', '1', NULL, '2025-12-03 16:56:14', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('95', '1', NULL, '2025-12-03 16:56:21', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('96', '1', NULL, '2025-12-03 17:03:21', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('97', '1', NULL, '2025-12-03 17:03:29', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('98', '1', NULL, '2025-12-03 17:03:53', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('99', '1', NULL, '2025-12-03 17:06:21', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: HC-2025-0002', 'Media');
INSERT INTO `log_auditoria` VALUES ('100', '1', NULL, '2025-12-03 17:06:28', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: HC-2025-0001', 'Media');
INSERT INTO `log_auditoria` VALUES ('101', '1', NULL, '2025-12-03 17:06:36', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('102', '1', NULL, '2025-12-03 17:06:43', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('103', '1', NULL, '2025-12-03 17:06:48', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('104', '1', NULL, '2025-12-03 17:06:54', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('105', '1', NULL, '2025-12-03 17:07:18', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('106', '1', NULL, '2025-12-03 17:07:20', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-03', 'Media');
INSERT INTO `log_auditoria` VALUES ('107', '1', NULL, '2025-12-03 17:07:33', 'LOGOUT', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Cierre de sesión', 'Media');
INSERT INTO `log_auditoria` VALUES ('108', '1', NULL, '2025-12-03 17:13:44', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('109', '1', NULL, '2025-12-03 17:13:55', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('110', '1', NULL, '2025-12-03 17:18:09', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('111', '1', NULL, '2025-12-03 17:18:33', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('112', '1', NULL, '2025-12-04 00:52:04', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('113', '1', NULL, '2025-12-04 01:19:42', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('114', '1', NULL, '2025-12-04 01:51:20', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('115', '1', NULL, '2025-12-04 01:54:09', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('116', '1', NULL, '2025-12-04 01:59:24', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-04', 'Media');
INSERT INTO `log_auditoria` VALUES ('117', '1', NULL, '2025-12-04 02:01:38', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-04', 'Media');
INSERT INTO `log_auditoria` VALUES ('118', '1', NULL, '2025-12-04 02:02:28', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-04', 'Media');
INSERT INTO `log_auditoria` VALUES ('119', '1', NULL, '2025-12-04 02:05:35', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('120', '1', NULL, '2025-12-04 11:50:06', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('121', '1', NULL, '2025-12-04 15:09:07', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('122', '1', NULL, '2025-12-04 15:12:17', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('123', '1', NULL, '2025-12-04 15:13:47', 'INSERT', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Nuevo paciente registrado: JULIO ANDRES LUNASCO - HC: HC-2025-0003', 'Media');
INSERT INTO `log_auditoria` VALUES ('124', '1', NULL, '2025-12-04 15:13:53', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('125', '1', NULL, '2025-12-04 15:38:24', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('126', '1', NULL, '2025-12-04 15:41:52', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('127', '1', NULL, '2025-12-04 15:46:40', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('128', '1', NULL, '2025-12-04 15:55:15', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('129', '1', NULL, '2025-12-04 15:55:23', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('130', '1', NULL, '2025-12-04 15:57:45', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('131', '1', NULL, '2025-12-04 15:57:58', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('132', '1', NULL, '2025-12-04 15:58:12', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('133', '1', NULL, '2025-12-04 15:58:23', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('134', '1', NULL, '2025-12-04 15:58:38', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('135', '1', NULL, '2025-12-04 16:00:19', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('136', '1', NULL, '2025-12-04 16:00:25', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('137', '1', NULL, '2025-12-04 16:00:35', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('138', '1', NULL, '2025-12-04 16:01:15', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('139', '1', NULL, '2025-12-04 16:01:28', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('140', '1', NULL, '2025-12-04 16:07:02', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('141', '1', NULL, '2025-12-04 16:07:16', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('142', '1', NULL, '2025-12-04 16:08:58', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('143', '1', NULL, '2025-12-04 16:09:15', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('144', '1', NULL, '2025-12-04 16:09:15', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('145', '1', NULL, '2025-12-04 16:09:31', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('146', '1', NULL, '2025-12-04 16:09:32', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('147', '1', NULL, '2025-12-04 16:12:23', 'UPDATE', 'paciente', '3', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('148', '1', NULL, '2025-12-04 16:12:23', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('149', '1', NULL, '2025-12-04 16:15:17', 'UPDATE', 'paciente', '2', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('150', '1', NULL, '2025-12-04 16:15:17', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('151', '1', NULL, '2025-12-04 16:17:13', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('152', '1', NULL, '2025-12-04 16:17:23', 'UPDATE', 'paciente', '2', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('153', '1', NULL, '2025-12-04 16:17:24', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('154', '1', NULL, '2025-12-04 16:17:35', 'UPDATE', 'paciente', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('155', '1', NULL, '2025-12-04 16:17:35', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('156', '1', NULL, '2025-12-04 16:17:44', 'UPDATE', 'paciente', '3', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de paciente por usuario 1', 'Media');
INSERT INTO `log_auditoria` VALUES ('157', '1', NULL, '2025-12-04 16:17:44', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('158', '1', NULL, '2025-12-04 16:17:53', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('159', '1', NULL, '2025-12-04 16:18:24', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('160', '1', NULL, '2025-12-04 16:20:30', 'INSERT', 'paciente', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Nuevo paciente registrado: CARLA TEBA MAMANI MAMANI - HC: HC-2025-0004', 'Media');
INSERT INTO `log_auditoria` VALUES ('161', '1', NULL, '2025-12-04 16:20:33', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('162', '1', NULL, '2025-12-04 16:21:42', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: Carla', 'Media');
INSERT INTO `log_auditoria` VALUES ('163', '1', NULL, '2025-12-04 16:21:46', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: CARLA', 'Media');
INSERT INTO `log_auditoria` VALUES ('164', '1', NULL, '2025-12-04 16:21:50', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: CARLA', 'Media');
INSERT INTO `log_auditoria` VALUES ('165', '1', NULL, '2025-12-04 16:21:52', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('166', '1', NULL, '2025-12-04 16:22:02', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: HC-2025-0004', 'Media');
INSERT INTO `log_auditoria` VALUES ('167', '1', NULL, '2025-12-04 16:22:06', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('168', '1', NULL, '2025-12-04 16:30:39', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('169', '1', NULL, '2025-12-04 16:30:42', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: CARLA', 'Media');
INSERT INTO `log_auditoria` VALUES ('170', '1', NULL, '2025-12-04 16:30:47', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('171', '1', NULL, '2025-12-04 16:30:51', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: HC-2025-0004', 'Media');
INSERT INTO `log_auditoria` VALUES ('172', '1', NULL, '2025-12-04 16:30:54', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('173', '1', NULL, '2025-12-04 16:30:59', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: MAMANI', 'Media');
INSERT INTO `log_auditoria` VALUES ('174', '1', NULL, '2025-12-04 16:31:06', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('175', '1', NULL, '2025-12-04 16:31:11', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('176', '1', NULL, '2025-12-04 16:31:15', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('177', '1', NULL, '2025-12-04 16:31:20', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda:  ESTEBAN', 'Media');
INSERT INTO `log_auditoria` VALUES ('178', '1', NULL, '2025-12-05 01:36:29', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('179', '1', NULL, '2025-12-05 01:38:35', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('180', '1', NULL, '2025-12-05 01:45:38', 'INSERT', 'personal', '6', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: DANTE SIRIO OMEGA MEL', 'Media');
INSERT INTO `log_auditoria` VALUES ('181', '1', NULL, '2025-12-05 01:45:43', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('182', '1', NULL, '2025-12-05 01:57:25', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('183', '1', NULL, '2025-12-05 01:58:57', 'INSERT', 'personal', '7', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: LEONARDO BENJA RAMOS QUITANILLA', 'Media');
INSERT INTO `log_auditoria` VALUES ('184', '1', NULL, '2025-12-05 01:59:04', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('185', '1', NULL, '2025-12-05 02:00:48', 'UPDATE', 'personal', '7', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de personal: LEONARDO BENJAMIN RAMOS QUITANILLA', 'Media');
INSERT INTO `log_auditoria` VALUES ('186', '1', NULL, '2025-12-05 02:00:52', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('187', '1', NULL, '2025-12-05 02:07:51', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('188', '1', NULL, '2025-12-05 02:13:29', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('189', '1', NULL, '2025-12-05 02:16:26', 'INSERT', 'personal', '8', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: LUIS ALBERTO MARTINEZ GUITIERREZ', 'Media');
INSERT INTO `log_auditoria` VALUES ('190', '1', NULL, '2025-12-05 02:16:37', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('191', '1', NULL, '2025-12-05 02:17:18', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('192', '1', NULL, '2025-12-05 02:19:33', 'INSERT', 'personal', '9', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: ANA MARIA RODRIGUEZ LOPEZ', 'Media');
INSERT INTO `log_auditoria` VALUES ('193', '1', NULL, '2025-12-05 02:24:12', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('194', '1', NULL, '2025-12-05 02:25:20', 'INSERT', 'personal', '10', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: CARLOS JOSE PEREZ GARCIA', 'Media');
INSERT INTO `log_auditoria` VALUES ('195', '1', NULL, '2025-12-05 02:29:08', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('196', '1', NULL, '2025-12-05 02:30:20', 'INSERT', 'personal', '11', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: MARIA ELENA GONZALES DIAZ', 'Media');
INSERT INTO `log_auditoria` VALUES ('197', '1', NULL, '2025-12-05 02:30:54', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('198', '1', NULL, '2025-12-05 02:31:56', 'INSERT', 'personal', '12', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: JUAN CARLOS FERNANDO RUIZ', 'Media');
INSERT INTO `log_auditoria` VALUES ('199', '1', NULL, '2025-12-05 02:32:58', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('200', '1', NULL, '2025-12-05 02:34:52', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('201', '1', NULL, '2025-12-05 02:36:05', 'INSERT', 'personal', '13', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: LAURA BEATRIZ SANCHEZ MUNOS', 'Media');
INSERT INTO `log_auditoria` VALUES ('202', '1', NULL, '2025-12-05 02:36:10', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('203', '1', NULL, '2025-12-05 02:36:34', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ADM003', 'Media');
INSERT INTO `log_auditoria` VALUES ('204', '1', NULL, '2025-12-05 02:36:38', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('205', '1', NULL, '2025-12-05 02:37:03', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('206', '1', NULL, '2025-12-05 02:37:32', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('207', '1', NULL, '2025-12-05 02:44:51', 'INSERT', 'personal', '14', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: PEDRO PABLO RAMIREZ GIMENEZ', 'Media');
INSERT INTO `log_auditoria` VALUES ('208', '1', NULL, '2025-12-05 02:50:27', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('209', '1', NULL, '2025-12-05 02:52:39', 'INSERT', 'personal', '16', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: SOFIA ISABEL TORREZ HERRERA', 'Media');
INSERT INTO `log_auditoria` VALUES ('210', '1', NULL, '2025-12-05 02:53:15', 'INSERT', 'medico', '16', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro completo de médico: SOFIA ISABEL TORREZ HERRERA', 'Media');
INSERT INTO `log_auditoria` VALUES ('211', '1', NULL, '2025-12-05 02:54:02', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('212', '1', NULL, '2025-12-05 02:54:06', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('213', '1', NULL, '2025-12-05 02:56:07', 'INSERT', 'personal', '17', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: DIEGO ALEJANDRO FLORES CASTRO', 'Media');
INSERT INTO `log_auditoria` VALUES ('214', '1', NULL, '2025-12-05 02:56:08', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('215', '1', NULL, '2025-12-05 03:02:29', 'INSERT', 'personal', '19', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: CAMILA ANDRES VARGAS ROJAS', 'Media');
INSERT INTO `log_auditoria` VALUES ('216', '1', NULL, '2025-12-05 03:02:30', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('217', '1', NULL, '2025-12-05 03:03:43', 'INSERT', 'personal', '20', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro de nuevo personal: JORGE EDUARDO MENDOZA ORTEGA', 'Media');
INSERT INTO `log_auditoria` VALUES ('218', '1', NULL, '2025-12-05 03:04:05', 'INSERT', 'medico', '20', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro completo de médico: JORGE EDUARDO MENDOZA ORTEGA', 'Media');
INSERT INTO `log_auditoria` VALUES ('219', '1', NULL, '2025-12-05 03:04:07', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('220', '1', NULL, '2025-12-05 03:05:26', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('221', '1', NULL, '2025-12-05 03:05:40', 'UPDATE', 'personal', '11', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Edición de personal: MARIA ELENITA GONZALES DIAZ', 'Media');
INSERT INTO `log_auditoria` VALUES ('222', '1', NULL, '2025-12-05 03:05:40', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('223', '1', NULL, '2025-12-05 03:09:20', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('224', '1', NULL, '2025-12-05 03:22:21', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('225', '1', NULL, '2025-12-05 03:22:25', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('226', '1', NULL, '2025-12-05 03:22:35', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('227', '1', NULL, '2025-12-05 03:22:38', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('228', '1', NULL, '2025-12-05 03:22:42', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('229', '1', NULL, '2025-12-05 03:23:24', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: JUAN', 'Media');
INSERT INTO `log_auditoria` VALUES ('230', '1', NULL, '2025-12-05 03:23:27', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('231', '1', NULL, '2025-12-05 03:23:41', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('232', '1', NULL, '2025-12-05 03:43:02', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('233', '1', NULL, '2025-12-05 03:44:43', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('234', '1', NULL, '2025-12-05 03:44:56', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('235', '1', NULL, '2025-12-05 11:17:51', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('236', '1', NULL, '2025-12-05 11:17:58', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('237', '1', NULL, '2025-12-05 11:22:29', 'INSERT', 'medico', '14', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro completo de médico: PEDRO PABLO RAMIREZ GIMENEZ', 'Media');
INSERT INTO `log_auditoria` VALUES ('238', '1', NULL, '2025-12-05 11:22:32', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('239', '1', NULL, '2025-12-05 11:24:02', 'INSERT', 'medico', '7', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro completo de médico: LEONARDO BENJAMIN RAMOS QUITANILLA', 'Media');
INSERT INTO `log_auditoria` VALUES ('240', '1', NULL, '2025-12-05 11:24:04', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('241', '1', NULL, '2025-12-05 11:25:06', 'INSERT', 'medico', '10', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro completo de médico: CARLOS JOSE PEREZ GARCIA', 'Media');
INSERT INTO `log_auditoria` VALUES ('242', '1', NULL, '2025-12-05 11:25:08', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('243', '1', NULL, '2025-12-05 11:31:47', 'INSERT', 'medico', '8', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro completo de médico: LUIS ALBERTO MARTINEZ GUITIERREZ', 'Media');
INSERT INTO `log_auditoria` VALUES ('244', '1', NULL, '2025-12-05 11:31:49', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('245', '1', NULL, '2025-12-05 11:32:27', 'INSERT', 'medico', '6', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro completo de médico: DANTE SIRIO OMEGA MEL', 'Media');
INSERT INTO `log_auditoria` VALUES ('246', '1', NULL, '2025-12-05 11:32:28', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('247', '1', NULL, '2025-12-05 11:33:11', 'INSERT', 'medico', '11', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Registro completo de médico: MARIA ELENITA GONZALES DIAZ', 'Media');
INSERT INTO `log_auditoria` VALUES ('248', '1', NULL, '2025-12-05 11:33:13', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('249', '1', NULL, '2025-12-05 11:33:38', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('250', '1', NULL, '2025-12-05 11:37:52', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('251', '1', NULL, '2025-12-05 11:37:58', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: JUAN', 'Media');
INSERT INTO `log_auditoria` VALUES ('252', '1', NULL, '2025-12-05 11:38:02', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('253', '1', NULL, '2025-12-05 11:56:04', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('254', '1', NULL, '2025-12-05 11:56:40', 'INSERT', 'horario_medico', '2', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('255', '1', NULL, '2025-12-05 11:56:56', 'INSERT', 'horario_medico', '3', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('256', '1', NULL, '2025-12-05 11:57:09', 'INSERT', 'horario_medico', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('257', '1', NULL, '2025-12-05 11:57:27', 'INSERT', 'horario_medico', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('258', '1', NULL, '2025-12-05 11:57:41', 'INSERT', 'horario_medico', '6', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('259', '1', NULL, '2025-12-05 11:57:54', 'INSERT', 'horario_medico', '7', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('260', '1', NULL, '2025-12-05 12:15:14', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('261', '1', NULL, '2025-12-05 12:15:25', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('262', '1', NULL, '2025-12-05 12:15:44', 'INSERT', 'horario_medico', '8', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('263', '1', NULL, '2025-12-05 12:15:52', 'INSERT', 'horario_medico', '9', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('264', '1', NULL, '2025-12-05 12:16:01', 'INSERT', 'horario_medico', '10', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('265', '1', NULL, '2025-12-05 12:16:12', 'INSERT', 'horario_medico', '11', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('266', '1', NULL, '2025-12-05 12:16:21', 'INSERT', 'horario_medico', '12', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('267', '1', NULL, '2025-12-05 12:16:32', 'INSERT', 'horario_medico', '13', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('268', '1', NULL, '2025-12-05 12:16:37', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('269', '1', NULL, '2025-12-05 12:16:50', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('270', '1', NULL, '2025-12-05 12:17:02', 'INSERT', 'horario_medico', '14', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('271', '1', NULL, '2025-12-05 12:17:08', 'INSERT', 'horario_medico', '15', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('272', '1', NULL, '2025-12-05 12:17:14', 'INSERT', 'horario_medico', '16', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('273', '1', NULL, '2025-12-05 12:17:21', 'INSERT', 'horario_medico', '17', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('274', '1', NULL, '2025-12-05 12:17:29', 'INSERT', 'horario_medico', '18', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('275', '1', NULL, '2025-12-05 12:17:36', 'INSERT', 'horario_medico', '19', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('276', '1', NULL, '2025-12-05 12:17:42', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('277', '1', NULL, '2025-12-05 12:17:47', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('278', '1', NULL, '2025-12-05 12:17:57', 'INSERT', 'horario_medico', '20', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('279', '1', NULL, '2025-12-05 12:18:04', 'INSERT', 'horario_medico', '21', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('280', '1', NULL, '2025-12-05 12:18:11', 'INSERT', 'horario_medico', '22', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('281', '1', NULL, '2025-12-05 12:18:19', 'INSERT', 'horario_medico', '23', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('282', '1', NULL, '2025-12-05 12:18:25', 'INSERT', 'horario_medico', '24', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('283', '1', NULL, '2025-12-05 12:18:34', 'INSERT', 'horario_medico', '25', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('284', '1', NULL, '2025-12-05 12:18:36', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('285', '1', NULL, '2025-12-05 12:18:41', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('286', '1', NULL, '2025-12-05 12:18:51', 'INSERT', 'horario_medico', '26', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('287', '1', NULL, '2025-12-05 12:18:55', 'DELETE', 'horario_medico', '26', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Eliminación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('288', '1', NULL, '2025-12-05 12:19:03', 'INSERT', 'horario_medico', '27', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('289', '1', NULL, '2025-12-05 12:19:10', 'INSERT', 'horario_medico', '28', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('290', '1', NULL, '2025-12-05 12:19:17', 'INSERT', 'horario_medico', '29', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('291', '1', NULL, '2025-12-05 12:19:26', 'INSERT', 'horario_medico', '30', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('292', '1', NULL, '2025-12-05 12:19:33', 'INSERT', 'horario_medico', '31', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('293', '1', NULL, '2025-12-05 12:19:44', 'INSERT', 'horario_medico', '32', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('294', '1', NULL, '2025-12-05 12:19:48', 'DELETE', 'horario_medico', '32', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Eliminación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('295', '1', NULL, '2025-12-05 12:19:56', 'INSERT', 'horario_medico', '33', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('296', '1', NULL, '2025-12-05 12:20:01', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('297', '1', NULL, '2025-12-05 12:20:05', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('298', '1', NULL, '2025-12-05 12:20:15', 'INSERT', 'horario_medico', '34', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('299', '1', NULL, '2025-12-05 12:20:24', 'INSERT', 'horario_medico', '35', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('300', '1', NULL, '2025-12-05 12:20:30', 'INSERT', 'horario_medico', '36', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('301', '1', NULL, '2025-12-05 12:20:37', 'INSERT', 'horario_medico', '37', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('302', '1', NULL, '2025-12-05 12:20:45', 'INSERT', 'horario_medico', '38', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('303', '1', NULL, '2025-12-05 12:20:52', 'INSERT', 'horario_medico', '39', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('304', '1', NULL, '2025-12-05 12:20:54', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('305', '1', NULL, '2025-12-05 12:20:58', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('306', '1', NULL, '2025-12-05 12:21:07', 'INSERT', 'horario_medico', '40', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('307', '1', NULL, '2025-12-05 12:21:16', 'INSERT', 'horario_medico', '41', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('308', '1', NULL, '2025-12-05 12:21:21', 'INSERT', 'horario_medico', '42', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('309', '1', NULL, '2025-12-05 12:21:31', 'INSERT', 'horario_medico', '43', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('310', '1', NULL, '2025-12-05 12:21:46', 'INSERT', 'horario_medico', '44', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('311', '1', NULL, '2025-12-05 12:21:54', 'INSERT', 'horario_medico', '45', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('312', '1', NULL, '2025-12-05 12:21:58', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('313', '1', NULL, '2025-12-05 12:22:01', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('314', '1', NULL, '2025-12-05 12:22:10', 'INSERT', 'horario_medico', '46', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('315', '1', NULL, '2025-12-05 12:22:16', 'INSERT', 'horario_medico', '47', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('316', '1', NULL, '2025-12-05 12:22:24', 'INSERT', 'horario_medico', '48', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('317', '1', NULL, '2025-12-05 12:22:31', 'INSERT', 'horario_medico', '49', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('318', '1', NULL, '2025-12-05 12:22:38', 'INSERT', 'horario_medico', '50', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('319', '1', NULL, '2025-12-05 12:22:46', 'INSERT', 'horario_medico', '51', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Creación de horario', 'Media');
INSERT INTO `log_auditoria` VALUES ('320', '1', NULL, '2025-12-05 12:22:50', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('321', '1', NULL, '2025-12-05 12:22:56', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('322', '1', NULL, '2025-12-05 12:24:09', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('323', '1', NULL, '2025-12-05 12:24:28', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('324', '1', NULL, '2025-12-05 12:25:35', 'INSERT', 'cita', '1', NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Cita programada para el 2025-12-08 a las 14:00', 'Media');
INSERT INTO `log_auditoria` VALUES ('325', '1', NULL, '2025-12-05 12:27:00', 'UPDATE', 'cita', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Cita confirmada', 'Media');
INSERT INTO `log_auditoria` VALUES ('326', '1', NULL, '2025-12-05 12:29:09', 'INSERT', 'cita', '2', NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Cita programada para el 2025-12-05 a las 13:00', 'Media');
INSERT INTO `log_auditoria` VALUES ('327', '1', NULL, '2025-12-05 12:29:33', 'UPDATE', 'cita', '2', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Cita confirmada', 'Media');
INSERT INTO `log_auditoria` VALUES ('328', '1', NULL, '2025-12-05 12:29:40', 'UPDATE', 'cita', '2', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Cita marcada como atendida', 'Media');
INSERT INTO `log_auditoria` VALUES ('329', '1', NULL, '2025-12-05 12:30:31', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('330', '1', NULL, '2025-12-05 12:32:09', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('331', '1', NULL, '2025-12-05 12:32:16', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('332', '1', NULL, '2025-12-05 12:32:24', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('333', '1', NULL, '2025-12-05 13:00:41', 'INSERT', 'internamiento', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Internamiento registrado para paciente #3', 'Media');
INSERT INTO `log_auditoria` VALUES ('334', '1', NULL, '2025-12-05 13:01:58', 'INSERT', 'evolucion_medica', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Evolución médica registrada para internamiento #1', 'Media');
INSERT INTO `log_auditoria` VALUES ('335', '1', NULL, '2025-12-05 15:26:52', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('336', '1', NULL, '2025-12-05 15:34:50', 'INSERT', 'medicamento', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Ibuprofeno', 'Media');
INSERT INTO `log_auditoria` VALUES ('337', '1', NULL, '2025-12-05 15:35:17', 'UPDATE', 'medicamento', '1', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento actualizado', 'Media');
INSERT INTO `log_auditoria` VALUES ('338', '1', NULL, '2025-12-05 15:35:57', 'INSERT', 'medicamento', '2', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Amoxicilina', 'Media');
INSERT INTO `log_auditoria` VALUES ('339', '1', NULL, '2025-12-05 15:37:28', 'INSERT', 'medicamento', '3', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Metformina', 'Media');
INSERT INTO `log_auditoria` VALUES ('340', '1', NULL, '2025-12-05 15:38:07', 'INSERT', 'medicamento', '4', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Losartán', 'Media');
INSERT INTO `log_auditoria` VALUES ('341', '1', NULL, '2025-12-05 15:38:49', 'INSERT', 'medicamento', '5', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Paracetamol', 'Media');
INSERT INTO `log_auditoria` VALUES ('342', '1', NULL, '2025-12-05 15:39:57', 'INSERT', 'medicamento', '6', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Cetirizina', 'Media');
INSERT INTO `log_auditoria` VALUES ('343', '1', NULL, '2025-12-05 15:41:01', 'INSERT', 'medicamento', '7', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Morfina', 'Media');
INSERT INTO `log_auditoria` VALUES ('344', '1', NULL, '2025-12-05 15:42:11', 'INSERT', 'medicamento', '8', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Clonazepam', 'Media');
INSERT INTO `log_auditoria` VALUES ('345', '1', NULL, '2025-12-05 15:42:54', 'INSERT', 'medicamento', '9', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Diclofenaco', 'Media');
INSERT INTO `log_auditoria` VALUES ('346', '1', NULL, '2025-12-05 15:45:36', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('347', '1', NULL, '2025-12-05 15:45:51', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('348', '1', NULL, '2025-12-05 15:46:00', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('349', '1', NULL, '2025-12-05 15:46:13', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('350', '1', NULL, '2025-12-05 15:46:22', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('351', '1', NULL, '2025-12-05 15:46:42', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('352', '1', NULL, '2025-12-05 15:46:52', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('353', '1', NULL, '2025-12-05 15:47:02', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('354', '1', NULL, '2025-12-05 15:47:11', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('355', '1', NULL, '2025-12-05 15:47:19', 'INSERT', 'movimiento_inventario', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Movimiento registrado: Entrada', 'Media');
INSERT INTO `log_auditoria` VALUES ('356', '1', NULL, '2025-12-05 15:49:56', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('357', '1', NULL, '2025-12-05 15:52:05', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('358', '1', NULL, '2025-12-05 15:52:20', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('359', '1', NULL, '2025-12-05 15:55:51', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('360', '1', NULL, '2025-12-05 15:56:05', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('361', '1', NULL, '2025-12-05 15:56:58', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('362', '1', NULL, '2025-12-05 15:57:16', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('363', '1', NULL, '2025-12-05 15:58:11', '', 'estadisticas', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Accedió a estadísticas detalladas - Período: 30 días', 'Media');
INSERT INTO `log_auditoria` VALUES ('364', '1', NULL, '2025-12-05 16:02:04', '', 'estadisticas', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Accedió a estadísticas detalladas - Período: 30 días', 'Media');
INSERT INTO `log_auditoria` VALUES ('365', '1', NULL, '2025-12-05 16:02:12', '', 'estadisticas', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Accedió a estadísticas detalladas - Período: 90 días', 'Media');
INSERT INTO `log_auditoria` VALUES ('366', '1', NULL, '2025-12-05 16:02:22', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('367', '1', NULL, '2025-12-05 16:02:34', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte personal de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('368', '1', NULL, '2025-12-05 16:02:49', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte citas de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('369', '1', NULL, '2025-12-05 16:03:28', '', 'estadisticas', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Accedió a estadísticas detalladas - Período: 30 días', 'Media');
INSERT INTO `log_auditoria` VALUES ('370', '1', NULL, '2025-12-05 16:03:46', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('371', '1', NULL, '2025-12-05 16:09:09', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('372', '1', NULL, '2025-12-05 16:09:57', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('373', '1', NULL, '2025-12-05 16:09:59', '', 'estadisticas', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Accedió a estadísticas detalladas - Período: 30 días', 'Media');
INSERT INTO `log_auditoria` VALUES ('374', '1', NULL, '2025-12-05 16:10:05', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte pacientes de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('375', '1', NULL, '2025-12-05 16:10:13', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte internamientos de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('376', '1', NULL, '2025-12-05 16:10:16', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte citas de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('377', '1', NULL, '2025-12-05 16:15:02', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('378', '1', NULL, '2025-12-05 16:15:16', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('379', '1', NULL, '2025-12-05 16:15:35', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('380', '1', NULL, '2025-12-05 16:15:38', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('381', '1', NULL, '2025-12-05 16:15:50', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte inventario de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('382', '1', NULL, '2025-12-05 16:15:54', 'EXPORT', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Exportado Excel: inventario de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('383', '1', NULL, '2025-12-05 16:16:03', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte inventario de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('384', '1', NULL, '2025-12-05 16:16:05', 'EXPORT', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Exportado CSV: inventario de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('385', '1', NULL, '2025-12-05 16:16:24', 'SELECT', 'personal', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de personal - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('386', '1', NULL, '2025-12-05 16:26:58', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('387', '1', NULL, '2025-12-05 17:11:48', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('388', '1', NULL, '2025-12-05 17:19:50', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('389', '1', NULL, '2025-12-05 17:37:42', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('390', '1', NULL, '2025-12-05 17:37:56', 'SELECT', 'paciente', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Listado de pacientes - Búsqueda: ', 'Media');
INSERT INTO `log_auditoria` VALUES ('391', '1', NULL, '2025-12-05 18:02:37', 'SELECT', 'reporte', NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Acceso a panel de reportes desde 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('392', '1', NULL, '2025-12-05 18:02:45', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte pacientes de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('393', '1', NULL, '2025-12-05 18:03:09', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte pacientes de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('394', '1', NULL, '2025-12-05 18:03:24', '', 'reporte', '0', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Generado reporte pacientes de 2025-12-01 a 2025-12-05', 'Media');
INSERT INTO `log_auditoria` VALUES ('395', '1', NULL, '2025-12-05 22:18:25', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('396', '1', NULL, '2025-12-05 22:19:40', 'INSERT', 'medicamento', '10', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Éxito', NULL, 'Medicamento registrado: Davo', 'Media');
INSERT INTO `log_auditoria` VALUES ('397', '1', NULL, '2025-12-05 23:22:17', 'LOGIN', NULL, NULL, NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Inicio de sesión exitoso', 'Media');
INSERT INTO `log_auditoria` VALUES ('398', '1', NULL, '2025-12-05 23:45:42', 'DELETE', 'backup', '2', NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Backup eliminado: Completo', 'Alta');
INSERT INTO `log_auditoria` VALUES ('399', '1', NULL, '2025-12-05 23:45:45', 'DELETE', 'backup', '1', NULL, NULL, '::1', NULL, 'Éxito', NULL, 'Backup eliminado: Completo', 'Alta');

-- --------------------------------------------------------
-- Estructura de tabla para `lote_medicamento`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `lote_medicamento`;
CREATE TABLE `lote_medicamento` (
  `id_lote` int(11) NOT NULL AUTO_INCREMENT,
  `id_medicamento` int(11) NOT NULL,
  `numero_lote` varchar(50) NOT NULL,
  `fecha_fabricacion` date NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  `cantidad_inicial` int(11) NOT NULL,
  `cantidad_actual` int(11) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `fecha_ingreso` timestamp NOT NULL DEFAULT current_timestamp(),
  `ubicacion_almacen` varchar(100) DEFAULT NULL,
  `estado_lote` enum('Disponible','Por vencer','Vencido','Agotado') DEFAULT 'Disponible',
  PRIMARY KEY (`id_lote`),
  UNIQUE KEY `unique_lote` (`id_medicamento`,`numero_lote`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `idx_medicamento` (`id_medicamento`),
  KEY `idx_fecha_vencimiento` (`fecha_vencimiento`),
  KEY `idx_estado_lote` (`estado_lote`),
  CONSTRAINT `lote_medicamento_ibfk_1` FOREIGN KEY (`id_medicamento`) REFERENCES `medicamento` (`id_medicamento`),
  CONSTRAINT `lote_medicamento_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`),
  CONSTRAINT `chk_cantidad_lote` CHECK (`cantidad_actual` >= 0 and `cantidad_actual` <= `cantidad_inicial`),
  CONSTRAINT `chk_fechas_lote` CHECK (`fecha_vencimiento` > `fecha_fabricacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Lotes de medicamentos';

-- --------------------------------------------------------
-- Estructura de tabla para `medicamento`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `medicamento`;
CREATE TABLE `medicamento` (
  `id_medicamento` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_medicamento` varchar(50) NOT NULL,
  `nombre_generico` varchar(200) NOT NULL,
  `nombre_comercial` varchar(200) DEFAULT NULL,
  `id_categoria` int(11) NOT NULL,
  `presentacion` enum('Tableta','Cápsula','Jarabe','Suspensión','Inyectable','Ampolla','Crema','Ungüento','Gotas','Spray','Supositorio','Parche') NOT NULL,
  `concentracion` varchar(50) DEFAULT NULL,
  `unidad_medida` varchar(20) DEFAULT NULL,
  `via_administracion` enum('Oral','Intravenosa','Intramuscular','Subcutánea','Tópica','Oftálmica','Ótica','Nasal','Rectal','Transdérmica') DEFAULT NULL,
  `laboratorio_fabricante` varchar(200) DEFAULT NULL,
  `requiere_receta` tinyint(1) DEFAULT 1,
  `controlado` tinyint(1) DEFAULT 0,
  `refrigeracion_requerida` tinyint(1) DEFAULT 0,
  `precio_unitario` decimal(10,2) NOT NULL,
  `stock_minimo` int(11) DEFAULT 10,
  `stock_actual` int(11) DEFAULT 0,
  `punto_reorden` int(11) DEFAULT 20,
  `estado` enum('Activo','Descontinuado','Suspendido') DEFAULT 'Activo',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_medicamento`),
  UNIQUE KEY `codigo_medicamento` (`codigo_medicamento`),
  KEY `idx_codigo` (`codigo_medicamento`),
  KEY `idx_nombre_generico` (`nombre_generico`),
  KEY `idx_nombre_comercial` (`nombre_comercial`),
  KEY `idx_categoria` (`id_categoria`),
  KEY `idx_stock` (`stock_actual`),
  KEY `idx_estado` (`estado`),
  CONSTRAINT `medicamento_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria_medicamento` (`id_categoria`),
  CONSTRAINT `chk_stock_positivo` CHECK (`stock_actual` >= 0)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Catálogo de medicamentos';

-- Volcado de datos para la tabla `medicamento`

INSERT INTO `medicamento` VALUES ('1', 'MED-001', 'Ibuprofeno', 'Dolorfin Fast', '1', 'Tableta', '400mg', NULL, NULL, NULL, '1', '0', '0', '2.50', '10', '100', '20', 'Activo', '2025-12-05 15:34:50');
INSERT INTO `medicamento` VALUES ('2', 'MED-002', 'Amoxicilina', 'AmoxiLab', '2', 'Cápsula', '500mg', NULL, NULL, NULL, '1', '0', '0', '4.80', '10', '100', '20', 'Activo', '2025-12-05 15:35:57');
INSERT INTO `medicamento` VALUES ('3', 'MED-003', 'Metformina', 'Glucontrol XR', '8', 'Tableta', '850mg', NULL, NULL, NULL, '1', '0', '0', '3.20', '40', '250', '20', 'Activo', '2025-12-05 15:37:28');
INSERT INTO `medicamento` VALUES ('4', 'MED-004', 'Losartán', 'Hipertensal', '5', 'Tableta', '50mg', NULL, NULL, NULL, '1', '0', '0', '5.75', '40', '100', '20', 'Activo', '2025-12-05 15:38:07');
INSERT INTO `medicamento` VALUES ('5', 'MED-005', 'Paracetamol', 'Febrex', '1', 'Jarabe', '120mg', NULL, NULL, NULL, '1', '0', '0', '18.00', '40', '100', '20', 'Activo', '2025-12-05 15:38:49');
INSERT INTO `medicamento` VALUES ('6', 'MED-006', 'Cetirizina', 'AlerZina', '3', 'Tableta', '10mg', NULL, NULL, NULL, '1', '0', '0', '1.80', '40', '100', '20', 'Activo', '2025-12-05 15:39:57');
INSERT INTO `medicamento` VALUES ('7', 'MED-007', 'Morfina', 'Morfanil', '1', 'Ampolla', '10mg', NULL, NULL, NULL, '1', '0', '0', '45.50', '40', '120', '20', 'Activo', '2025-12-05 15:41:01');
INSERT INTO `medicamento` VALUES ('8', 'MED-008', 'Clonazepam', 'Neuryl', '6', 'Gotas', '2.5mg', NULL, NULL, NULL, '1', '0', '0', '32.40', '40', '100', '20', 'Activo', '2025-12-05 15:42:11');
INSERT INTO `medicamento` VALUES ('9', 'MED-009', 'Diclofenaco', 'DoloFlex Gel', '3', 'Crema', '30g', NULL, NULL, NULL, '1', '0', '0', '15.90', '40', '100', '20', 'Activo', '2025-12-05 15:42:54');
INSERT INTO `medicamento` VALUES ('10', 'MED-010', 'Davo', 'Cuatrodoce', '2', 'Inyectable', '500mg', NULL, NULL, NULL, '1', '0', '0', '2.40', '10', '0', '20', 'Activo', '2025-12-05 22:19:40');

-- --------------------------------------------------------
-- Estructura de tabla para `medico`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `medico`;
CREATE TABLE `medico` (
  `id_medico` int(11) NOT NULL,
  `id_especialidad` int(11) NOT NULL,
  `numero_colegiatura` varchar(50) NOT NULL,
  `universidad` varchar(200) DEFAULT NULL,
  `anios_experiencia` int(11) DEFAULT 0,
  `curriculum_vitae` text DEFAULT NULL,
  `firma_digital` blob DEFAULT NULL,
  `disponible_consulta` tinyint(1) DEFAULT 1,
  `costo_consulta` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_medico`),
  UNIQUE KEY `numero_colegiatura` (`numero_colegiatura`),
  KEY `idx_especialidad` (`id_especialidad`),
  KEY `idx_colegiatura` (`numero_colegiatura`),
  KEY `idx_disponible` (`disponible_consulta`),
  CONSTRAINT `medico_ibfk_1` FOREIGN KEY (`id_medico`) REFERENCES `personal` (`id_personal`) ON DELETE CASCADE,
  CONSTRAINT `medico_ibfk_2` FOREIGN KEY (`id_especialidad`) REFERENCES `especialidad` (`id_especialidad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Información específica de médicos';

-- Volcado de datos para la tabla `medico`

INSERT INTO `medico` VALUES ('6', '1', 'COL-84956', 'UNIVERSIDAD PALERMO', '4', NULL, NULL, '1', '100.00');
INSERT INTO `medico` VALUES ('7', '8', 'COL-95623', 'UNIVERSIDAD MAYOR DE SAN ANDRES', '5', NULL, NULL, '1', '300.00');
INSERT INTO `medico` VALUES ('8', '6', 'COL-54656', 'UNIVERSIDAD MAYOR DE SAN ANDRES', '5', NULL, NULL, '1', '300.00');
INSERT INTO `medico` VALUES ('10', '5', 'COL-78956', 'UNIVERSIDAD UPEA', '2', NULL, NULL, '1', '150.00');
INSERT INTO `medico` VALUES ('11', '5', 'COL-15659', 'UNIVERSIDAD FRANZ TAMAYO', '6', NULL, NULL, '1', '150.00');
INSERT INTO `medico` VALUES ('14', '3', 'COL-78451', 'UNIVERSIDAD FRANZ TAMAYO', '1', NULL, NULL, '1', '30.00');
INSERT INTO `medico` VALUES ('16', '3', 'COL-12345', 'UNIVERSIDAD UNIVALLE', '3', NULL, NULL, '1', '200.00');
INSERT INTO `medico` VALUES ('20', '3', 'COL-12346', 'UNIVERSIDAD BANCO SOL', '2', NULL, NULL, '1', '300.00');

-- --------------------------------------------------------
-- Estructura de tabla para `movimiento_inventario`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `movimiento_inventario`;
CREATE TABLE `movimiento_inventario` (
  `id_movimiento` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_movimiento` enum('Entrada','Salida','Ajuste','Devolución','Merma','Vencimiento','Transferencia') NOT NULL,
  `id_medicamento` int(11) NOT NULL,
  `id_lote` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  `motivo` varchar(200) NOT NULL,
  `id_proveedor` int(11) DEFAULT NULL COMMENT 'Para entradas/compras',
  `id_receta` int(11) DEFAULT NULL COMMENT 'Para salidas por dispensación',
  `id_usuario_registra` int(11) NOT NULL,
  `costo_unitario` decimal(10,2) DEFAULT NULL,
  `costo_total` decimal(10,2) DEFAULT NULL,
  `stock_anterior` int(11) NOT NULL,
  `stock_posterior` int(11) NOT NULL,
  `observaciones` text DEFAULT NULL,
  `numero_comprobante` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_movimiento`),
  KEY `id_lote` (`id_lote`),
  KEY `id_proveedor` (`id_proveedor`),
  KEY `id_receta` (`id_receta`),
  KEY `idx_tipo` (`tipo_movimiento`),
  KEY `idx_medicamento` (`id_medicamento`),
  KEY `idx_fecha` (`fecha_hora`),
  KEY `idx_usuario` (`id_usuario_registra`),
  CONSTRAINT `movimiento_inventario_ibfk_1` FOREIGN KEY (`id_medicamento`) REFERENCES `medicamento` (`id_medicamento`),
  CONSTRAINT `movimiento_inventario_ibfk_2` FOREIGN KEY (`id_lote`) REFERENCES `lote_medicamento` (`id_lote`),
  CONSTRAINT `movimiento_inventario_ibfk_3` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`),
  CONSTRAINT `movimiento_inventario_ibfk_4` FOREIGN KEY (`id_receta`) REFERENCES `receta_medica` (`id_receta`),
  CONSTRAINT `chk_cantidad_movimiento` CHECK (`cantidad` > 0)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Movimientos de inventario';

-- Volcado de datos para la tabla `movimiento_inventario`

INSERT INTO `movimiento_inventario` VALUES ('1', 'Entrada', '2', NULL, '100', '2025-12-05 15:45:36', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '4.80', '480.00', '0', '100', NULL, NULL);
INSERT INTO `movimiento_inventario` VALUES ('2', 'Entrada', '6', NULL, '100', '2025-12-05 15:45:51', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '1.80', '180.00', '0', '100', NULL, NULL);
INSERT INTO `movimiento_inventario` VALUES ('3', 'Entrada', '8', NULL, '100', '2025-12-05 15:46:00', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '32.40', '3240.00', '0', '100', NULL, NULL);
INSERT INTO `movimiento_inventario` VALUES ('4', 'Entrada', '9', NULL, '100', '2025-12-05 15:46:13', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '15.90', '1590.00', '0', '100', NULL, NULL);
INSERT INTO `movimiento_inventario` VALUES ('5', 'Entrada', '1', NULL, '100', '2025-12-05 15:46:22', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '2.50', '250.00', '0', '100', NULL, NULL);
INSERT INTO `movimiento_inventario` VALUES ('6', 'Entrada', '4', NULL, '100', '2025-12-05 15:46:42', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '5.75', '575.00', '0', '100', NULL, NULL);
INSERT INTO `movimiento_inventario` VALUES ('7', 'Entrada', '3', NULL, '100', '2025-12-05 15:46:52', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '3.20', '320.00', '0', '100', NULL, NULL);
INSERT INTO `movimiento_inventario` VALUES ('8', 'Entrada', '3', NULL, '150', '2025-12-05 15:47:02', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '3.20', '480.00', '100', '250', NULL, NULL);
INSERT INTO `movimiento_inventario` VALUES ('9', 'Entrada', '7', NULL, '120', '2025-12-05 15:47:11', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '45.50', '5460.00', '0', '120', NULL, NULL);
INSERT INTO `movimiento_inventario` VALUES ('10', 'Entrada', '5', NULL, '100', '2025-12-05 15:47:19', 'Se compraron nuevos medicamentos', NULL, NULL, '1', '18.00', '1800.00', '0', '100', NULL, NULL);

-- --------------------------------------------------------
-- Estructura de tabla para `orden_examen`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `orden_examen`;
CREATE TABLE `orden_examen` (
  `id_orden` int(11) NOT NULL AUTO_INCREMENT,
  `id_documento` int(11) NOT NULL,
  `tipo_examen` enum('Sangre','Orina','Heces','Imagenología','Electrocardiograma','Ecografía','Radiografía','Tomografía','Resonancia','Biopsia','Otro') NOT NULL,
  `nombre_examen` varchar(200) NOT NULL,
  `indicaciones` text DEFAULT NULL COMMENT 'Encriptado',
  `urgente` tinyint(1) DEFAULT 0,
  `ayuno_requerido` tinyint(1) DEFAULT 0,
  `preparacion_especial` text DEFAULT NULL,
  `estado_orden` enum('Pendiente','En proceso','Completado','Cancelado') DEFAULT 'Pendiente',
  `fecha_realizacion` timestamp NULL DEFAULT NULL,
  `costo_examen` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_orden`),
  UNIQUE KEY `id_documento` (`id_documento`),
  KEY `idx_tipo_examen` (`tipo_examen`),
  KEY `idx_estado` (`estado_orden`),
  KEY `idx_urgente` (`urgente`),
  CONSTRAINT `orden_examen_ibfk_1` FOREIGN KEY (`id_documento`) REFERENCES `documento_medico` (`id_documento`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Órdenes de exámenes médicos';

-- --------------------------------------------------------
-- Estructura de tabla para `paciente`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `paciente`;
CREATE TABLE `paciente` (
  `id_paciente` int(11) NOT NULL,
  `grupo_sanguineo` enum('A+','A-','B+','B-','AB+','AB-','O+','O-') DEFAULT NULL,
  `factor_rh` enum('+','-') DEFAULT NULL,
  `alergias` text DEFAULT NULL COMMENT 'Encriptado',
  `enfermedades_cronicas` text DEFAULT NULL COMMENT 'Encriptado',
  `contacto_emergencia_nombre` varbinary(255) DEFAULT NULL COMMENT 'Encriptado',
  `contacto_emergencia_telefono` varbinary(255) DEFAULT NULL COMMENT 'Encriptado',
  `contacto_emergencia_relacion` varchar(50) DEFAULT NULL,
  `seguro_medico` varchar(100) DEFAULT NULL,
  `numero_poliza` varbinary(255) DEFAULT NULL COMMENT 'Encriptado',
  `fecha_primera_consulta` date DEFAULT NULL,
  `numero_historia_clinica` varchar(50) DEFAULT NULL,
  `estado_paciente` enum('activo','inactivo','fallecido') DEFAULT 'activo',
  PRIMARY KEY (`id_paciente`),
  UNIQUE KEY `numero_historia_clinica` (`numero_historia_clinica`),
  KEY `idx_grupo_sanguineo` (`grupo_sanguineo`),
  KEY `idx_numero_historia` (`numero_historia_clinica`),
  KEY `idx_estado_paciente` (`estado_paciente`),
  CONSTRAINT `paciente_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `persona` (`id_persona`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Información específica de pacientes';

-- Volcado de datos para la tabla `paciente`

INSERT INTO `paciente` VALUES ('2', 'B-', '-', 'N', 'N', 'aXBtVDFiYVpXdW9jSE9SQk1nSXJwMDFvK1VCcFREaDhMY1FSdlovOVJhaz06Og8SS1MwTT5Hm5usTcKVpzA=', 'N09ueG04aDhkbzdjdEQ4Z0RpeXdtdz09Ojovdr6cpFkDmLCltC/OWXiq', 'Padre/Madre', '', '', '2025-11-30', 'HC-2025-0001', 'activo');
INSERT INTO `paciente` VALUES ('3', 'AB+', '+', 'N', 'N', 'RHlhcnlVOE15MWtITnNXb1pEMDQ1Zz09Ojo3jW6ldpn8swh2hsYQa4uL', 'T1RldFdBbWJSeDBxNE0vS2x0bTVKQT09Ojr1Ov6zkBxkNfNrN2teDKmm', 'Padre/Madre', '', '', '2025-11-30', 'HC-2025-0002', 'activo');
INSERT INTO `paciente` VALUES ('4', 'AB+', '+', 'N', 'N', 'Tk1mSEJRdGNmaHg4cVFOckJaOHVhdz09OjqNmBdbt9AvlB3nmq+AQ1IY', 'U1R2SmUwRENGMnJvVmoyZkkvdlZPZz09OjpkIKetCWKfGlUf+pvN3WP4', 'Padre/Madre', '', '', '2025-12-04', 'HC-2025-0003', 'activo');
INSERT INTO `paciente` VALUES ('5', 'AB-', '-', 'Mariscos', 'Diabetes tipo 1', 'VTFSVFJtajdXSlVyWGlYejR4UWpEK1B4NEZYRWxiRnVOL1ZtZXdmRDhUTT06OgYgaZW46hLI1qviAF0uQIA=', 'Zm5kZEJOMW13ZDA2c2NLc01VSmIvdz09Ojov/ke3jWtJMurYRmhypQV+', 'Padre/Madre', '', '', '2025-12-04', 'HC-2025-0004', 'activo');

-- --------------------------------------------------------
-- Estructura de tabla para `permiso`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `permiso`;
CREATE TABLE `permiso` (
  `id_permiso` int(11) NOT NULL AUTO_INCREMENT,
  `modulo` varchar(100) NOT NULL,
  `accion` enum('Crear','Leer','Actualizar','Eliminar','Ejecutar','Exportar','Imprimir') NOT NULL,
  `descripcion` text DEFAULT NULL,
  `codigo_permiso` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_permiso`),
  UNIQUE KEY `unique_modulo_accion` (`modulo`,`accion`),
  UNIQUE KEY `codigo_permiso` (`codigo_permiso`),
  KEY `idx_modulo` (`modulo`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Permisos del sistema';

-- Volcado de datos para la tabla `permiso`

INSERT INTO `permiso` VALUES ('1', 'Pacientes', 'Crear', 'Registrar nuevos pacientes', 'PAC_CREATE');
INSERT INTO `permiso` VALUES ('2', 'Pacientes', 'Leer', 'Ver información de pacientes', 'PAC_READ');
INSERT INTO `permiso` VALUES ('3', 'Pacientes', 'Actualizar', 'Modificar datos de pacientes', 'PAC_UPDATE');
INSERT INTO `permiso` VALUES ('4', 'Pacientes', 'Eliminar', 'Eliminar registros de pacientes', 'PAC_DELETE');
INSERT INTO `permiso` VALUES ('5', 'Citas', 'Crear', 'Agendar citas', 'CIT_CREATE');
INSERT INTO `permiso` VALUES ('6', 'Citas', 'Leer', 'Ver citas', 'CIT_READ');
INSERT INTO `permiso` VALUES ('7', 'Citas', 'Actualizar', 'Modificar citas', 'CIT_UPDATE');
INSERT INTO `permiso` VALUES ('8', 'Citas', 'Eliminar', 'Cancelar citas', 'CIT_DELETE');
INSERT INTO `permiso` VALUES ('9', 'Consultas', 'Crear', 'Registrar consultas', 'CON_CREATE');
INSERT INTO `permiso` VALUES ('10', 'Consultas', 'Leer', 'Ver consultas', 'CON_READ');
INSERT INTO `permiso` VALUES ('11', 'Historial', 'Leer', 'Ver historial clínico', 'HIS_READ');
INSERT INTO `permiso` VALUES ('12', 'Historial', 'Actualizar', 'Actualizar historial', 'HIS_UPDATE');
INSERT INTO `permiso` VALUES ('13', 'Medicamentos', 'Crear', 'Registrar medicamentos', 'MED_CREATE');
INSERT INTO `permiso` VALUES ('14', 'Medicamentos', 'Leer', 'Ver inventario', 'MED_READ');
INSERT INTO `permiso` VALUES ('15', 'Medicamentos', 'Actualizar', 'Modificar inventario', 'MED_UPDATE');
INSERT INTO `permiso` VALUES ('16', 'Internamiento', 'Crear', 'Registrar internamiento', 'INT_CREATE');
INSERT INTO `permiso` VALUES ('17', 'Internamiento', 'Leer', 'Ver internamientos', 'INT_READ');
INSERT INTO `permiso` VALUES ('18', 'Reportes', 'Ejecutar', 'Generar reportes', 'REP_EXECUTE');
INSERT INTO `permiso` VALUES ('19', 'Auditoria', 'Leer', 'Ver logs de auditoría', 'AUD_READ');
INSERT INTO `permiso` VALUES ('20', 'Usuarios', 'Crear', 'Crear usuarios', 'USR_CREATE');
INSERT INTO `permiso` VALUES ('21', 'Usuarios', 'Actualizar', 'Modificar usuarios', 'USR_UPDATE');

-- --------------------------------------------------------
-- Estructura de tabla para `persona`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `persona`;
CREATE TABLE `persona` (
  `id_persona` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_documento` enum('DNI','Pasaporte','CI','RUC','Otro') NOT NULL,
  `numero_documento` varbinary(255) NOT NULL COMMENT 'Encriptado',
  `nombres` varbinary(255) NOT NULL COMMENT 'Encriptado',
  `apellidos` varbinary(255) NOT NULL COMMENT 'Encriptado',
  `fecha_nacimiento` varbinary(255) DEFAULT NULL COMMENT 'Encriptado',
  `genero` enum('M','F','Otro','Prefiero no decir') NOT NULL,
  `telefono` varbinary(255) DEFAULT NULL COMMENT 'Encriptado',
  `email` varbinary(255) DEFAULT NULL COMMENT 'Encriptado',
  `direccion` varbinary(512) DEFAULT NULL COMMENT 'Encriptado',
  `ciudad` varchar(100) DEFAULT NULL,
  `pais` varchar(100) DEFAULT 'Bolivia',
  `foto_perfil` varchar(255) DEFAULT NULL,
  `estado` enum('activo','inactivo') DEFAULT 'activo',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `usuario_crea` int(11) DEFAULT NULL,
  `usuario_modifica` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_persona`),
  UNIQUE KEY `unique_documento` (`tipo_documento`,`numero_documento`(100)),
  KEY `idx_estado` (`estado`),
  KEY `idx_ciudad` (`ciudad`),
  KEY `idx_fecha_registro` (`fecha_registro`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabla padre para todas las personas';

-- Volcado de datos para la tabla `persona`

INSERT INTO `persona` VALUES ('1', 'CI', 'MTIzNDU2Nzg=', 'QWRtaW4=', 'U2lzdGVtYQ==', NULL, 'M', NULL, NULL, NULL, 'La Paz', 'Bolivia', NULL, 'activo', '2025-11-30 03:45:35', '2025-11-30 03:45:35', NULL, NULL);
INSERT INTO `persona` VALUES ('2', 'CI', 'VUFPZDhyb21QS3BWVE1VOFhUUi9rZz09OjolVPcW2diZ3Iz0eDT6+bsZ', 'dXVCWVFrcEZ0djVpVXQyUXFYRWt5Zz09Ojo7NEGfvCl3S89fltglItiP', 'dllTdzFYZlU3LzBoYmNKdHNqa1c2QT09OjriBwxtAL7xovVAIN6DsM/3', 'TGdEM3JUbnBHZGpVbFEwV0Ewb0ZHUT09OjoVuOq5hqAm0ZojBmfLOaR2', 'M', 'MWtQMVQwV2lBQWF1UmNTRll0ZVRKZz09OjoO9WM7MesDBKA5ajesD1eX', 'UFNoYmVFK1FzN2tQVU9iRXBhSTVjMHUybW1LclJGd1ZOTEhteG14YlBIYz06OkQKfPbQdMnQPaPKnjUwQZc=', 'UjdNWjBBMFFMMlNYWGpxTXlvZ0xSUy91TnpDbmFjcXNoTVlIYUtkMlo2az06Omy/LVpm+g1QjYQs3rWyB4E=', 'La Paz', 'Bolivia', NULL, 'activo', '2025-11-30 03:47:43', '2025-12-04 16:17:23', '1', '1');
INSERT INTO `persona` VALUES ('3', 'CI', 'bHgzL1p1eHE2b2V5UXV5RnR6V3crdz09OjosfPCkKjS3fgV1NVW3AFYR', 'ZUtUbGNXMlh1OURKVWJXYVNCYkF2QT09OjoQTljWFZT/pA91mJfa5GWt', 'cS9pOUV6ckZCbUtSUzBkUjB4c0xVQT09OjpFW5XlSS6lNu3639nK+Uwc', 'YUVabmlTMnNTSHdueCs4YWwxWWNZQT09OjopczYGcGCR4dqX4tfcx7yP', 'M', 'eXQ1ZWdEM2xBak9aRHFCVUsrZXBjUT09OjpknL8AUAij1yLi5jg+rw4Y', 'emxHdVIwVkxhN29SaWJIeCs2SmpoME5MbmFoQjBSTEgwdDYwUy95c0pZWT06Oti6U6uO+X4rNrWJu5AVALQ=', 'bDBzVUlBUDI5SFlzUjZvVkZ0OUFDUmt0RDhZbFovc1lyMlhaTWJ5SjZjRT06OniHuFPMMeKT646PhAw9E9M=', 'La Paz', 'Bolivia', NULL, 'activo', '2025-11-30 21:26:36', '2025-12-04 16:17:44', '1', '1');
INSERT INTO `persona` VALUES ('4', 'CI', 'Y3JqaFVlSWFCZXV1Nkk3OE14RHB1UT09OjqVgw0aTyIlWp4x7DgzCdmG', 'UEZ4RS9wTC9VVTlwVDRXMUpoNE9pQT09OjqaNe7hEHxeiXWCtWN/O9nc', 'cFBjSnN5RitxUzJpQXpQSXRMb1YzUT09OjpXKWTKiGR8f4P7qOXgW16/', 'WW4xR3FIYlNZdk9iLzVDeGlxQkxEdz09OjotW4Z9w7DjW8evao4lo4nZ', 'M', 'N0JGSzNMWUlHWVlUdUs5WGQ3R2ZCZz09Ojr0E+7iKtdPX64WOOW/lDyJ', 'Y1RNY3hTSkVqaXZKZ3AzZTlKeFhkOXR4T2JPdUhzemNDL3FoLzFYVmFxcz06Oq0s5jHCDWung2DboBOlwLQ=', 'SGFrOXVsaFFwcVlWTHVheFRsNkVudz09Ojo4AgHau9HikiyQvBpCpGiR', 'La Paz', 'Bolivia', NULL, 'activo', '2025-12-04 15:13:47', '2025-12-04 16:17:35', '1', '1');
INSERT INTO `persona` VALUES ('5', 'CI', 'eU1EVi9UKzZHbFROQ2xBbVhldlV2dz09OjqwPsTUzA+b+M+rAuMbNOdW', 'blVQaTFqQXNlcGFuelRoR01zMWVRdz09OjrVj+I8ljG34nH93HDoF0ph', 'TWxvVDVSV2wrcFduQ1JQM3ZmSnp0dz09OjqpSNaV7ANlxIMJgLAhBzEy', 'SGQ3MS9JRTJIYkRDdytqSkYzNWJ1QT09OjqJEBW9LFTOU70KpRAnGO3a', 'M', 'bHdSd0tuRVZET1E3RldyN0hDZUd5dz09Ojo2I7KnKtc4PSrwgfzLfGn/', 'Y1gvQnY0MnJybWR3alg0OGoxSTZYUT09OjrrvpdmGXgIQ81ESJjZPHTA', 'UzNDNmZjU0wwZVZDNlp5UE00WHF2M1BRVjVzWXdDZEhIbjhpT0tBejJlTT06OnvP0h7cuwroQ7ZVoftEg6Y=', 'La Paz', 'Bolivia', NULL, 'activo', '2025-12-04 16:20:30', '2025-12-04 16:20:30', '1', NULL);
INSERT INTO `persona` VALUES ('6', 'CI', 'QmlCUW0vVS9Ed0JxL3FZV0hLMUVTdz09OjpwkRpKq16LqM0b01GOmc8B', 'WjVDS25HWnc4d0pXdFRSMzN1MGQ3QT09OjockpfN+fPkvJ0WVBgTNnbX', 'WWpadGM5alAzMmtxWXA4V2JTckFxUT09OjouWjk8/KWDTe2Ehh/R+5Nz', '1994-09-12', 'M', 'dkw0blpaOEp5N2lHZFcyTTRSVkdiUT09Ojp3s05dkzdLqdDjK0wpX2xV', 'Q25xOVQrMCtpaktHazZsaHZrNmdMQT09OjpdSQD6vHwzauP0HJNpMUQH', NULL, 'LA PAZ', 'Bolivia', NULL, 'activo', '2025-12-05 01:45:38', '2025-12-05 01:45:38', '1', NULL);
INSERT INTO `persona` VALUES ('7', 'CI', 'b2JsUVZlU25xMUhiRU1oNWxQWVhxUT09OjoxYHqqhXG7GsJYhMRw1ToC', 'TUwzWnYyTlZGZ0tGbGMwWGdSZU1teWZCekJaSnRjUjZwMkcrS3czb0t5cz06OvGgJjKq1jLXdbLGcjozuhk=', 'dmptc2FNc2E0OThySnpiYVd4Y29rVDZPbzFMWWdwVUwvNnZDa2hlQTdsQT06OtZ2QmO89jlfO7KNQ9w2ZDk=', '1996-06-13', 'M', 'OElvSVpkNDRpMXVUVFZZUDlKdWc0dz09OjoWOPwm1ys867JrfZ8hFW0Q', 'aElvc0lwbjdpREN3cTRwbVpzdFJIQklnNlVrbDEzeHBvRXd5UGE3cVYwbz06Oio5VCpFSmOjVrQ+YLMTZ04=', NULL, 'Cochabamba', 'Bolivia', NULL, 'activo', '2025-12-05 01:58:57', '2025-12-05 02:00:48', '1', '1');
INSERT INTO `persona` VALUES ('8', 'CI', 'Nk9iZ0JYbTBra3lrRXk5MVVpY2dYdz09Ojqj06UAF1Jg4q5ymR2whS1B', 'QU1wL3lLdmp3UDlFZ3h6RVdlR214QT09Ojrj5D/blel550dvlohHYy+o', 'WTZOTmRoTzZSV01jN09HdWswTktOMkM0RHlGRjBZdnlnMDF1MlkzRmdXaz06OurBmybDveIVecFyeYP95Lw=', '1945-06-18', 'M', 'Yk03eTllR0JIM2VpQktha3JueVBhZz09OjoaLKazfZZBxOC1sv/TEKVU', 'NGJJdVYvVG1Db2c2M3NPY0UrN2V5dz09OjqFAqsNTtWy+zssknrKweAs', NULL, 'Cochabamba', 'Bolivia', NULL, 'activo', '2025-12-05 02:16:25', '2025-12-05 02:16:25', '1', NULL);
INSERT INTO `persona` VALUES ('9', 'CI', 'T2FXZkNBc1daaTNvQ09TRTdEU3pOUT09OjoZWp6UNbzQUjE0SvOZiVGn', 'Z3BiRDJ3ZlRSdFlLUTJmVHJUOTRpdz09OjrIp8yvExuoT87whryxvo38', 'eG5vQ25KTkFnT25PUmNEcmJYbFJHdz09OjpBrlfvR9Ih425gNFHKXTnM', '1988-10-17', 'F', 'T21JMWprTHlDdGFKd2ZsbnA2UWx2dz09OjohjQkT3vwKoJeJzWzhKCbK', 'MjdvRTM1WmM4aFVDSkN2MnNGMk9Hdz09Ojo56NCHDGtvTqoHBduRJ+Ke', NULL, 'LA PAZ', 'Bolivia', NULL, 'activo', '2025-12-05 02:19:33', '2025-12-05 02:19:33', '1', NULL);
INSERT INTO `persona` VALUES ('10', 'CI', 'blNHR2o5N1ZUQU9BRGtldm1YWm11UT09OjpQ+Z0keTz2majTbUi1LQhI', 'QzBHdE9ad0J2R1VwYTdZSDlyYjNBUT09OjqSvRP3/3LO1CasV/+dnw+T', 'd0s0SVg5S3BMK3pBREdkL0h3Z1c2dz09OjrCPWQSWjhxB0r5fZxX+00R', '1978-09-04', 'M', 'cWxKYjlNcjZ5ZFJvVjlpZDFBOXNXdz09OjolpaKoN7qjBLz5f+EAsNZq', 'NW5zeE55SU5uc2FRc1l0TUlxUzRoOFp2UGk3UmxYNjNiVDFoV0VzZStGWT06OkTnnbfmvsCuAlGow1aqBn0=', NULL, 'La Paz', 'Bolivia', NULL, 'activo', '2025-12-05 02:25:20', '2025-12-05 02:25:20', '1', NULL);
INSERT INTO `persona` VALUES ('11', 'CI', 'Qy9tMytPMHJtRmI4eUFHS2hINmU2Zz09OjrglyPG1jGtKEPl2OU53krk', 'OEFaaE5kYlZSVU1UU0xNZlpLUVF4Zz09OjqT0hno832eCsuvIlJUikUL', 'cDBXeXUvUTZIREZqVTdRVkdNR2J2QT09OjoSiOI9+ih6haTfM93mrYp9', '1996-06-18', 'F', 'dmN0dHlWajQ4Z1VKNGVJdXFkdjdJUT09OjqPhQ7qRHVaWnFEUsq0WfyF', 'VTE2MzRuczNFVkxyU2FCa2xVZ0VVdz09OjqlwJJJm3QUQ1N3co3bf2uk', NULL, 'Cochabamba', 'Bolivia', NULL, 'activo', '2025-12-05 02:30:20', '2025-12-05 03:05:40', '1', '1');
INSERT INTO `persona` VALUES ('12', 'CI', 'Y1R2NWJLd2FQZzVmVE9mRjBrR2hwUT09OjozG6e6qzkjuk0+Q3HTzk4E', 'dHAyblZ5WkNFZ2ZLbkY4MTlKUS9LUT09OjoVFs3HpYUAP40UKiBpgSk4', 'MGhqVHVMVFhMMGUvbittUHp2a0J3QT09OjpjV/CjRkZPRv3uu1J3jC96', '1885-09-12', 'M', 'bjNDSHV0OFprSDdIVGZQZjNlOHM0Zz09OjrwGPD8HNkpyBMbFCyg2THa', 'YUpDby9sdFZhRHVhd05mdXBZZWlNVGc2RjNRVEt4UE96RVJ5R3A0QVpjOD06Ouf0X6xcQyY18A5ii3bM8ys=', NULL, 'Cochabamba', 'Bolivia', NULL, 'activo', '2025-12-05 02:31:56', '2025-12-05 02:31:56', '1', NULL);
INSERT INTO `persona` VALUES ('13', 'CI', 'ODNDLzl1LzZzSzYrdEZFMnBNRUUvdz09OjqSfPaBrh5HIqUwNLRiXBI6', 'R1E2TTIrL004MGdzTHRoa3FEVWlPdz09OjqcnGifd49ouczFLP8cke2u', 'aW5SUTMyaS8xS0xzc3lTU2hrWktCQT09OjpfUSCI5ai1rMwP3alcePt+', '1799-04-12', 'F', 'WksweWhnM09CQ1E2QURzdUpGK3lMQT09OjpvFS5/f48gxIjlmM7FuXdE', 'aTlZcEd6OWw1bzFEK0ZsOVR3cjlYdz09OjqJDf4IIIdiIDjXIu4GD33f', NULL, 'Chuquisaca', 'Bolivia', NULL, 'activo', '2025-12-05 02:36:05', '2025-12-05 02:36:05', '1', NULL);
INSERT INTO `persona` VALUES ('14', 'CI', 'WWp0cHpqZTMyd2JEMEhyWXZXendQUT09Ojo0CjXJN22RVi01AaiFbvn7', 'akNWNXpwemwzRGNNbXRoZXV4M0xJZz09OjrZyJWGzP6Q5nERrZmSs2Iy', 'UWN0dlREb0RpYThyOWZzWG96bWM2UT09OjpwNn5SLMjkqa3j4mTD9o6E', '1745-06-05', 'M', 'd2pVUUZyWEx1ZVdicU94d3NPK240Zz09OjqB8fp22MVwjojzdMsib3ns', 'NTRIUWIzRXNRZ2tQeXBmdmFGbXMrQT09Ojpy0sshb80f28pUTdZ70ULT', NULL, 'Santa Cruz', 'Bolivia', NULL, 'activo', '2025-12-05 02:44:51', '2025-12-05 02:44:51', '1', NULL);
INSERT INTO `persona` VALUES ('16', 'CI', 'M3JOSXQ0dHZLQ1Jsd0FNWUdVWUQwUT09OjqHMfhNM91Fyh9N2HgXhUrW', 'VjBqeEM1MVJ6TUpNYjBZaERLRFI2QT09Ojpss17ZEKN6M7PjV9PbVYRx', 'OE96TjhRYUp1RHZzcHhHTmZuTEVQQT09OjqAv8zOQUnLtkT4hIh0RgNr', '1999-06-05', 'F', 'R2R2eFpVeC9VaDQ2aEFTd3I4eGo3QT09OjqZaqUdOdp9oAU5BOV1APq9', 'NnpNQmV2aFZkN2dMMmljRkt5Qk1sUT09Ojr3gtN2zuuHLeINEw5cyaQM', NULL, 'Santa Cruz', 'Bolivia', NULL, 'activo', '2025-12-05 02:52:39', '2025-12-05 02:52:39', '1', NULL);
INSERT INTO `persona` VALUES ('17', 'CI', 'bUhMSXY1ZzY1MldCYTNVYXR5Y1pnZz09OjrWzKGz11ZsploZuExFLxZj', 'YnJqT1lqSDZsV0RYUTBmSXFLRUduUT09Ojr1dZqFoP2jJ2nDmjYzCijg', 'NVB2UTJqREVNdm8rbi9xQzJTcm5Pdz09Ojp/3cXr7HApKZ5nAKoeuVry', '1999-06-26', 'M', 'WkMwalJZUzh2alh0YVI4ZlNBOG03dz09OjrgL6Sn67W/kLh91e/YCYG6', 'amFHWDZFOXVpdXhXZmY4bW1TYUpDdz09OjpyyqbpJrTUX+zhAKmwFumj', NULL, 'La Paz', 'Bolivia', NULL, 'activo', '2025-12-05 02:56:07', '2025-12-05 02:56:07', '1', NULL);
INSERT INTO `persona` VALUES ('19', 'CI', 'TFI5THZUUE5EVzdlRXZ1cWVKSEJFdz09OjpDqrNFQhE8JUV5Fa42VClY', 'V3o1Y2RFcXY4cVU0dVZCblpCKzVFdz09OjqZekeywX2CuMe45oAGOF9o', 'elBwZ1hWZmN5eDJrekcxZis3bzU1Zz09OjpzYUmMi7acs6gMCGilJzUg', '1999-08-25', 'F', 'Rm1abHBDM3FxU2tVRTJqUzhNbUtPQT09OjrFEgYs/JNy6tBOuSoFzlA9', 'WkFrajZPZmVxdDhla1U4NE1oYkVkWGRzZ1k3WTBTMGRGVFB6b3AxLy9Zaz06OtGvSN8vI/c/2yW+lQXkrVs=', NULL, 'Potosi', 'Bolivia', NULL, 'activo', '2025-12-05 03:02:29', '2025-12-05 03:02:29', '1', NULL);
INSERT INTO `persona` VALUES ('20', 'CI', 'WnVQUk9CaFJwOGJ3SWJjY1Q4OUcvdz09Ojrj9yYvOwn9g0Ibgzk1twzB', 'c01pZGhrMDVrbHhVQlFYakcwS25qUT09OjrOpZhB4GduUcvaR5ygKjZl', 'MzFyaGkyanhXZUVoNkVBM1hZZCtlZz09OjpuCiQU2UczPIT/njRjooDO', '1995-07-15', 'M', 'NUxDVjdHWHZZOVJ1ZUpXN3dmQUVkZz09OjpHHuO3r2BgKFsqYkMHmWdG', 'NGNDNm16RjdwdzFoUG8wNEtWNGxJZz09OjpFPzM2avjGLdSusV4fJt9A', NULL, 'Potosi', 'Bolivia', NULL, 'activo', '2025-12-05 03:03:43', '2025-12-05 03:03:43', '1', NULL);

-- --------------------------------------------------------
-- Estructura de tabla para `personal`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `personal`;
CREATE TABLE `personal` (
  `id_personal` int(11) NOT NULL,
  `codigo_empleado` varchar(20) NOT NULL,
  `fecha_contratacion` date NOT NULL,
  `tipo_personal` enum('Medico','Enfermero','Administrativo','Laboratorio','Farmacia','Limpieza','Seguridad') NOT NULL,
  `id_departamento` int(11) DEFAULT NULL,
  `salario_base` decimal(10,2) DEFAULT NULL,
  `cuenta_bancaria` varbinary(255) DEFAULT NULL COMMENT 'Encriptado',
  `estado_laboral` enum('activo','vacaciones','licencia','baja','despedido') DEFAULT 'activo',
  `fecha_baja` date DEFAULT NULL,
  `motivo_baja` text DEFAULT NULL,
  PRIMARY KEY (`id_personal`),
  UNIQUE KEY `codigo_empleado` (`codigo_empleado`),
  KEY `idx_codigo_empleado` (`codigo_empleado`),
  KEY `idx_tipo_personal` (`tipo_personal`),
  KEY `idx_estado_laboral` (`estado_laboral`),
  KEY `idx_departamento` (`id_departamento`),
  CONSTRAINT `personal_ibfk_1` FOREIGN KEY (`id_personal`) REFERENCES `persona` (`id_persona`) ON DELETE CASCADE,
  CONSTRAINT `personal_ibfk_2` FOREIGN KEY (`id_departamento`) REFERENCES `departamento` (`id_departamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Información del personal del hospital';

-- Volcado de datos para la tabla `personal`

INSERT INTO `personal` VALUES ('1', 'ADM001', '2025-11-30', 'Administrativo', '1', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('6', 'EMP-001', '2025-12-05', 'Medico', '2', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('7', 'EMP-002', '2025-12-05', 'Medico', '3', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('8', 'EMP-003', '2025-05-07', 'Medico', '3', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('9', 'ADM002', '2025-12-05', 'Administrativo', '8', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('10', 'EMP-004', '2025-09-05', 'Medico', '4', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('11', 'EMP-005', '2025-12-05', 'Medico', NULL, NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('12', 'ADM003', '2025-12-05', 'Administrativo', '8', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('13', 'ADM004', '2025-12-05', 'Administrativo', '8', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('14', 'EMP-006', '2025-12-06', 'Medico', '2', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('16', 'EMP-007', '2025-05-08', 'Medico', '2', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('17', 'ADM005', '2025-08-05', 'Administrativo', '8', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('19', 'ADM006', '2025-06-05', 'Administrativo', '8', NULL, NULL, 'activo', NULL, NULL);
INSERT INTO `personal` VALUES ('20', 'EMP-008', '2025-11-08', 'Medico', '3', NULL, NULL, 'activo', NULL, NULL);

-- --------------------------------------------------------
-- Estructura de tabla para `politica_acceso`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `politica_acceso`;
CREATE TABLE `politica_acceso` (
  `id_politica` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo_restriccion` enum('IP','Horario','Ubicación','Dispositivo','Combinada') NOT NULL,
  `valor_restriccion` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Configuración específica' CHECK (json_valid(`valor_restriccion`)),
  `id_rol` int(11) DEFAULT NULL COMMENT 'NULL = aplica a todos',
  `activa` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `creado_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_politica`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `id_rol` (`id_rol`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_tipo` (`tipo_restriccion`),
  KEY `idx_activa` (`activa`),
  CONSTRAINT `politica_acceso_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`),
  CONSTRAINT `politica_acceso_ibfk_2` FOREIGN KEY (`creado_por`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Políticas de acceso contextual';

-- --------------------------------------------------------
-- Estructura de tabla para `proveedor`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `proveedor`;
CREATE TABLE `proveedor` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `razon_social` varchar(200) NOT NULL,
  `ruc` varchar(50) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` varchar(500) DEFAULT NULL,
  `ciudad` varchar(100) DEFAULT NULL,
  `pais` varchar(100) DEFAULT 'Bolivia',
  `contacto_nombre` varchar(200) DEFAULT NULL,
  `contacto_cargo` varchar(100) DEFAULT NULL,
  `contacto_telefono` varchar(20) DEFAULT NULL,
  `contacto_email` varchar(100) DEFAULT NULL,
  `calificacion` decimal(3,2) DEFAULT 5.00,
  `estado` enum('activo','inactivo','bloqueado') DEFAULT 'activo',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_proveedor`),
  UNIQUE KEY `ruc` (`ruc`),
  KEY `idx_razon_social` (`razon_social`),
  KEY `idx_ruc` (`ruc`),
  KEY `idx_estado` (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Proveedores de medicamentos';

-- --------------------------------------------------------
-- Estructura de tabla para `receta_medica`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `receta_medica`;
CREATE TABLE `receta_medica` (
  `id_receta` int(11) NOT NULL AUTO_INCREMENT,
  `id_documento` int(11) NOT NULL,
  `fecha_validez` date NOT NULL,
  `estado_receta` enum('Vigente','Vencida','Surtida parcial','Surtida total','Anulada') DEFAULT 'Vigente',
  `numero_receta` varchar(50) DEFAULT NULL,
  `observaciones_farmacia` text DEFAULT NULL,
  PRIMARY KEY (`id_receta`),
  UNIQUE KEY `id_documento` (`id_documento`),
  UNIQUE KEY `numero_receta` (`numero_receta`),
  KEY `idx_estado` (`estado_receta`),
  KEY `idx_fecha_validez` (`fecha_validez`),
  KEY `idx_numero` (`numero_receta`),
  CONSTRAINT `receta_medica_ibfk_1` FOREIGN KEY (`id_documento`) REFERENCES `documento_medico` (`id_documento`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Recetas médicas';

-- --------------------------------------------------------
-- Estructura de tabla para `restauracion`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `restauracion`;
CREATE TABLE `restauracion` (
  `id_restauracion` int(11) NOT NULL AUTO_INCREMENT,
  `id_backup` int(11) NOT NULL,
  `fecha_inicio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_fin` datetime DEFAULT NULL,
  `tipo_restauracion` enum('Completa','Parcial','Point in Time') NOT NULL,
  `tablas_restauradas` text DEFAULT NULL,
  `registros_restaurados` int(11) DEFAULT NULL,
  `estado_restauracion` enum('En proceso','Completado','Fallido','Revertido') DEFAULT 'En proceso',
  `motivo` text NOT NULL,
  `autorizado_por` int(11) DEFAULT NULL,
  `ejecutado_por` int(11) DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  PRIMARY KEY (`id_restauracion`),
  KEY `id_backup` (`id_backup`),
  KEY `autorizado_por` (`autorizado_por`),
  KEY `ejecutado_por` (`ejecutado_por`),
  KEY `idx_fecha` (`fecha_inicio`),
  KEY `idx_estado` (`estado_restauracion`),
  CONSTRAINT `restauracion_ibfk_1` FOREIGN KEY (`id_backup`) REFERENCES `backup` (`id_backup`),
  CONSTRAINT `restauracion_ibfk_2` FOREIGN KEY (`autorizado_por`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `restauracion_ibfk_3` FOREIGN KEY (`ejecutado_por`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registro de restauraciones';

-- --------------------------------------------------------
-- Estructura de tabla para `resultado_examen`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `resultado_examen`;
CREATE TABLE `resultado_examen` (
  `id_resultado` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) NOT NULL,
  `fecha_realizacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `resultado` text DEFAULT NULL COMMENT 'Encriptado',
  `valores_referencia` text DEFAULT NULL,
  `interpretacion` text DEFAULT NULL COMMENT 'Encriptado',
  `observaciones` text DEFAULT NULL COMMENT 'Encriptado',
  `id_personal_realiza` int(11) NOT NULL,
  `archivo_adjunto` varchar(500) DEFAULT NULL,
  `validado` tinyint(1) DEFAULT 0,
  `fecha_validacion` timestamp NULL DEFAULT NULL,
  `id_medico_valida` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_resultado`),
  KEY `id_personal_realiza` (`id_personal_realiza`),
  KEY `id_medico_valida` (`id_medico_valida`),
  KEY `idx_orden` (`id_orden`),
  KEY `idx_fecha` (`fecha_realizacion`),
  KEY `idx_validado` (`validado`),
  CONSTRAINT `resultado_examen_ibfk_1` FOREIGN KEY (`id_orden`) REFERENCES `orden_examen` (`id_orden`),
  CONSTRAINT `resultado_examen_ibfk_2` FOREIGN KEY (`id_personal_realiza`) REFERENCES `personal` (`id_personal`),
  CONSTRAINT `resultado_examen_ibfk_3` FOREIGN KEY (`id_medico_valida`) REFERENCES `medico` (`id_medico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Resultados de exámenes';

-- --------------------------------------------------------
-- Estructura de tabla para `rol`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `rol`;
CREATE TABLE `rol` (
  `id_rol` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `nivel_acceso` int(11) DEFAULT 1 COMMENT 'Nivel jerárquico de acceso',
  `estado` enum('activo','inactivo') DEFAULT 'activo',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `idx_nombre` (`nombre`),
  KEY `idx_nivel` (`nivel_acceso`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Roles del sistema';

-- Volcado de datos para la tabla `rol`

INSERT INTO `rol` VALUES ('1', 'Administrador', 'Acceso total al sistema', '10', 'activo', '2025-11-30 03:22:28');
INSERT INTO `rol` VALUES ('2', 'Médico', 'Acceso a funciones médicas', '7', 'activo', '2025-11-30 03:22:28');
INSERT INTO `rol` VALUES ('3', 'Enfermero', 'Acceso a atención de enfermería', '5', 'activo', '2025-11-30 03:22:28');
INSERT INTO `rol` VALUES ('4', 'Recepcionista', 'Gestión de citas y recepción', '3', 'activo', '2025-11-30 03:22:28');
INSERT INTO `rol` VALUES ('5', 'Farmacia', 'Gestión de inventario y dispensación', '5', 'activo', '2025-11-30 03:22:28');
INSERT INTO `rol` VALUES ('6', 'Laboratorio', 'Registro de resultados de exámenes', '5', 'activo', '2025-11-30 03:22:28');
INSERT INTO `rol` VALUES ('7', 'Paciente', 'Acceso limitado a su información', '1', 'activo', '2025-11-30 03:22:28');
INSERT INTO `rol` VALUES ('8', 'Auditor', 'Acceso de solo lectura para auditoría', '8', 'activo', '2025-11-30 03:22:28');

-- --------------------------------------------------------
-- Estructura de tabla para `rol_permiso`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `rol_permiso`;
CREATE TABLE `rol_permiso` (
  `id_rol` int(11) NOT NULL,
  `id_permiso` int(11) NOT NULL,
  `fecha_asignacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `asignado_por` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_rol`,`id_permiso`),
  KEY `idx_rol` (`id_rol`),
  KEY `idx_permiso` (`id_permiso`),
  CONSTRAINT `rol_permiso_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON DELETE CASCADE,
  CONSTRAINT `rol_permiso_ibfk_2` FOREIGN KEY (`id_permiso`) REFERENCES `permiso` (`id_permiso`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Relación roles-permisos';

-- --------------------------------------------------------
-- Estructura de tabla para `sala`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sala`;
CREATE TABLE `sala` (
  `id_sala` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo_sala` enum('General','UCI','Emergencias','Pediatría','Maternidad','Quirófano','Recuperación') NOT NULL,
  `piso` int(11) NOT NULL,
  `capacidad_camas` int(11) NOT NULL,
  `camas_ocupadas` int(11) DEFAULT 0,
  `responsable_enfermeria` int(11) DEFAULT NULL,
  `estado_sala` enum('Operativa','Mantenimiento','Cerrada') DEFAULT 'Operativa',
  PRIMARY KEY (`id_sala`),
  KEY `responsable_enfermeria` (`responsable_enfermeria`),
  KEY `idx_tipo` (`tipo_sala`),
  KEY `idx_piso` (`piso`),
  KEY `idx_estado` (`estado_sala`),
  CONSTRAINT `sala_ibfk_1` FOREIGN KEY (`responsable_enfermeria`) REFERENCES `personal` (`id_personal`),
  CONSTRAINT `chk_ocupacion` CHECK (`camas_ocupadas` >= 0 and `camas_ocupadas` <= `capacidad_camas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Salas del hospital';

-- --------------------------------------------------------
-- Estructura de tabla para `sesion`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sesion`;
CREATE TABLE `sesion` (
  `id_sesion` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `token_sesion` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `navegador` varchar(200) DEFAULT NULL,
  `sistema_operativo` varchar(100) DEFAULT NULL,
  `dispositivo` varchar(100) DEFAULT NULL,
  `ubicacion_geografica` varchar(200) DEFAULT NULL,
  `fecha_inicio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_ultima_actividad` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_cierre` timestamp NULL DEFAULT NULL,
  `duracion_minutos` int(11) DEFAULT NULL,
  `estado_sesion` enum('Activa','Cerrada','Expirada','Forzada a cerrar') DEFAULT 'Activa',
  PRIMARY KEY (`id_sesion`),
  UNIQUE KEY `token_sesion` (`token_sesion`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_token` (`token_sesion`),
  KEY `idx_estado` (`estado_sesion`),
  KEY `idx_fecha_inicio` (`fecha_inicio`),
  CONSTRAINT `sesion_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Sesiones de usuario';

-- Volcado de datos para la tabla `sesion`

INSERT INTO `sesion` VALUES ('1', '1', '0522fe36ccdbaf5f7b7c1db6a21007e2b345a9c25b41af5c3991e4aa7e0dc0c4', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Windows NT', NULL, NULL, '2025-11-30 03:46:50', '2025-11-30 03:51:46', '2025-11-30 03:51:46', '4', 'Cerrada');
INSERT INTO `sesion` VALUES ('2', '1', 'bbccb6b599e2bd1de3d99d65c50a25745a9c048adfb0e80efe288deb33ce98e7', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Windows NT', NULL, NULL, '2025-11-30 03:52:09', '2025-11-30 03:52:09', NULL, NULL, 'Activa');
INSERT INTO `sesion` VALUES ('3', '1', '932016c327e64b2ef6360a28406fa6ea38f650609ddd60471bb74e14a1b94d4a', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Windows NT', NULL, NULL, '2025-11-30 12:11:29', '2025-11-30 12:11:29', NULL, NULL, 'Activa');
INSERT INTO `sesion` VALUES ('4', '1', '934081e0f6781bdb99eab6f958a206d0c092b658eae537223d18533d210f4d2b', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Windows NT', NULL, NULL, '2025-11-30 12:30:13', '2025-11-30 12:33:19', '2025-11-30 12:33:19', '3', 'Cerrada');
INSERT INTO `sesion` VALUES ('5', '1', '8281d7add8c0df6441c73e467fb1780a08f4ac5468d0f5e76d89cdb078004647', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Windows NT', NULL, NULL, '2025-11-30 12:50:26', '2025-11-30 12:50:26', NULL, NULL, 'Activa');
INSERT INTO `sesion` VALUES ('6', '1', '74973aa73564063a092bdfd73044d7708e0095c7d6c5df5a3dd0085320c884b3', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Windows NT', NULL, NULL, '2025-11-30 21:25:08', '2025-11-30 21:29:56', '2025-11-30 21:29:56', '4', 'Cerrada');
INSERT INTO `sesion` VALUES ('7', '1', 'c25e445f9ebc080a72c34cea82eb314971b49374d8f70b4bea3725c33d3b5044', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Windows NT', NULL, NULL, '2025-11-30 21:30:01', '2025-11-30 22:34:06', '2025-11-30 22:34:06', '64', 'Cerrada');
INSERT INTO `sesion` VALUES ('8', '1', 'f80d3c15264db3a0d19c1b95fd21408375fba5e643cc14b61fc9329ec97414f4', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Windows NT', NULL, NULL, '2025-11-30 22:40:10', '2025-11-30 22:40:10', NULL, NULL, 'Activa');
INSERT INTO `sesion` VALUES ('9', '1', 'b5e77796d542a00af4cc40ac85a9794dd919fe61ce3aaaa3a15f3dead48cd1ab', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'Windows NT', NULL, NULL, '2025-11-30 23:47:32', '2025-11-30 23:59:47', '2025-11-30 23:59:47', '12', 'Cerrada');

-- --------------------------------------------------------
-- Estructura de tabla para `turno`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `turno`;
CREATE TABLE `turno` (
  `id_turno` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `tipo_turno` enum('Diurno','Nocturno','Rotativo','Guardia') NOT NULL,
  `estado` enum('activo','inactivo') DEFAULT 'activo',
  PRIMARY KEY (`id_turno`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `idx_nombre` (`nombre`),
  CONSTRAINT `chk_turno_valido` CHECK (`hora_fin` > `hora_inicio` or `nombre` = 'Guardia 24h')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Turnos de trabajo';

-- --------------------------------------------------------
-- Estructura de tabla para `usuario`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `id_persona` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL COMMENT 'SHA-256 + Salt',
  `password_salt` varchar(255) NOT NULL,
  `email_verificado` tinyint(1) DEFAULT 0,
  `telefono_verificado` tinyint(1) DEFAULT 0,
  `autenticacion_dos_factores` tinyint(1) DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultimo_acceso` timestamp NULL DEFAULT NULL,
  `ultima_ip` varchar(45) DEFAULT NULL,
  `intentos_fallidos` int(11) DEFAULT 0,
  `cuenta_bloqueada` tinyint(1) DEFAULT 0,
  `fecha_bloqueo` timestamp NULL DEFAULT NULL,
  `fecha_ultimo_cambio_password` timestamp NOT NULL DEFAULT current_timestamp(),
  `requiere_cambio_password` tinyint(1) DEFAULT 1,
  `token_recuperacion` varchar(255) DEFAULT NULL,
  `token_expiracion` timestamp NULL DEFAULT NULL,
  `estado` enum('activo','inactivo','bloqueado','suspendido') DEFAULT 'activo',
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `id_persona` (`id_persona`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`),
  KEY `idx_estado` (`estado`),
  KEY `idx_ultimo_acceso` (`ultimo_acceso`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id_persona`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Usuarios del sistema';

-- Volcado de datos para la tabla `usuario`

INSERT INTO `usuario` VALUES ('1', '1', 'admin', 'eeea7af566eaa1ec19871a5074808e5bd4df3e28644fab20e81ebfc69ca6bb8a', 'salt123', '0', '0', '0', '2025-11-30 03:45:35', '2025-12-05 23:22:17', '::1', '0', '0', NULL, '2025-11-30 03:45:35', '0', NULL, NULL, 'activo');

-- --------------------------------------------------------
-- Estructura de tabla para `usuario_rol`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `usuario_rol`;
CREATE TABLE `usuario_rol` (
  `id_usuario` int(11) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `fecha_asignacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `asignado_por` int(11) DEFAULT NULL,
  `fecha_vencimiento` date DEFAULT NULL COMMENT 'Para roles temporales',
  `estado` enum('activo','vencido','revocado') DEFAULT 'activo',
  PRIMARY KEY (`id_usuario`,`id_rol`),
  KEY `asignado_por` (`asignado_por`),
  KEY `idx_usuario` (`id_usuario`),
  KEY `idx_rol` (`id_rol`),
  KEY `idx_estado` (`estado`),
  CONSTRAINT `usuario_rol_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `usuario_rol_ibfk_2` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON DELETE CASCADE,
  CONSTRAINT `usuario_rol_ibfk_3` FOREIGN KEY (`asignado_por`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Relación usuarios-roles';

-- Volcado de datos para la tabla `usuario_rol`

INSERT INTO `usuario_rol` VALUES ('1', '1', '2025-11-30 03:45:35', NULL, NULL, 'activo');

SET FOREIGN_KEY_CHECKS=1;
COMMIT;
